# 公共组件
为了解决spring项目或spring-boot项目公共部分进行提取,方便项目搭建以及服务的集成,公共组件包括配置(Swagger,Debug模式,事务,请求序列化等)、常量、异常、Mapper、Service、监听器、过滤器等，针对各层可以继承基类方便应用开发，减少开发量
## 一. 公共配置
	-	系统线程池配置
	- 	swagger配置(包括跨域支持)
	- 	事务配置
	-	请求序列化使用fastjson进行序列化
	-            全局常量
	-	Debug模式(SYSTEM_DEBUG_VERBOSE=true)
## 二. 公共服务
### 1. Controller层
	基类BaseController为公共控制层，封装Ajax响应结果格式(分页、集合、单对象)
### 2. DAO层(MyBatis的Mapper)
	基类BaseMapper为公共数据访问层，封装数据库操作(增删改查以及Example操作)
### 3. Service层
          基类BaseService为公共业务层，对Example分页进行封装
### 4. Model层
	- entity 业务实体(基类BaseEntity包含pkid)：与数据库字段对应
	- req    请求实体(包括请求模型以及请求查询参数)
	  	- BaseModel 请求模型即对数据库进行insert或update操作
	    - KeywordReq 关键字查询(keyword),对关键字中%*'"等进行特殊处理
	    - PageKeywordReq 分页关键字查询(keyword),对关键字中%*'"等进行特殊处理
	    - PageReq 分页字查询
	    - PageDateReq 分页日期查询(startTime,endTime),对日期进行校验以及判断处理
	- resp    响应视图(基类BaseView包含pkid)
## 三. 过滤器
	SecurityGlobalFilter系统安全过滤器，对脚本注入、SQL注入等不安全因素进行过滤
## 四. 监听器
	SystemGlobalListener对系统初始化以及销毁收尾工作进行处理，在所有Spring加载之前进行
## 五. 异常及通知
	-   自定义系统异常：继承RuntimeException类并对异常进行扩展封装
	-   异常通知：主要是对请求接口后的后置异常进行捕获并可识别性的响应给前台(后置通知方式)

## 六. Kafka消息封装
对Spring-Kafka的生产端以及消费端进行封装，并对其参数进行调优，支持消费端单条、批量消费且主题可使用单主题、多主题以及模糊匹配主题等方式，应用基础方式：
#### 1. 	生产端：
    --- 配置参数
```properties
kafka.producer.enabled=false
kafka.servers=172.21.32.130:39092,172.21.32.131:19092,172.21.32.132:29092
kafka.zookeeper.enabled=true
kafka.zookeeper.servers=172.21.32.130:2183,172.21.32.131:2181,172.21.32.132:2182
kafka.topics=power_index_item_log
kafka.timeout.ms=30000
#producer
kafka.acks=all
kafka.retries=2147483647
kafka.batch.size=1048576
kafka.linger.ms=100
kafka.max.block.ms=9223372036854775807
kafka.buffer.memory=33554432
kafka.auto.flush=true
```
    --- 代码引用
```java
@Value("${kafka.producer.enabled:false}")
private boolean producer;

@Value("${kafka.servers:}")
private String servers;
@Value("${kafka.zookeeper.enabled:false}")
private boolean isZk;
@Value("${kafka.zookeeper.servers:}")
private String zkServers;
@Value("${kafka.topics:}")
private String topics;
@Value("${kafka.timeout:30000}")
private int timeout;

@Value("${kafka.acks:all}")
private String acks;
@Value("${kafka.retries:2147483647}")
private int retries;
@Value("${kafka.batch.size:1048576}")
private int batchSize;
@Value("${kafka.linger.ms:100}")
private int linger;
@Value("${kafka.max.block.ms:9223372036854775807}")
private long maxBlock;
@Value("${kafka.buffer.memory:33554432}")
private int memory;
@Value("${kafka.auto.flush:false}")
private boolean autoFlush;
@Bean
public KafkaProducerMessageListener kafkaProducerMessageListener() {
    producer = StringUtils.isNotBlank(System.getenv("KAFKA_PRODUCER_ENABLED"))?Boolean.parseBoolean(System.getenv("KAFKA_PRODUCER_ENABLED")):producer;
    if (!producer) {
        logger.info(">>>>>>>>>>> Kafka Producer Disabled.");
        return null;
    }
    logger.info(">>>>>>>>>>> Kafka Producer config init....");
    KafkaProducerMessageListener listener = new DefaultKafkaProducerMessageListener();
    KafkaProducerFactory factory = new KafkaProducerFactory();
    factory.setServers(servers);
    factory.setZk(isZk);
    factory.setZkServers(zkServers);
    factory.setRetries(retries);
    factory.setTimeout(timeout);
    factory.setTopics(topics);
    factory.setRunning(true);
    factory.setAcks(acks);
    factory.setAutoFlush(autoFlush);
    factory.setBatchSize(batchSize);
    factory.setLinger(linger);
    factory.setMaxBlock(maxBlock);
    factory.setMemory(memory);
    factory.setListener(listener);
    factory.start();
    return listener;
}
```
#### 2. 	消费端：
    --- 配置参数
```properties
kafka.consumer.enabled=false
kafka.servers=172.21.32.130:39092,172.21.32.131:19092,172.21.32.132:29092
kafka.zookeeper.enabled=true
kafka.zookeeper.servers=172.21.32.130:2183,172.21.32.131:2181,172.21.32.132:2182
kafka.topics=power_index_item_log
kafka.timeout.ms=30000
#consumer
kafka.group.id=manager_1
kafka.batch.commit=true
kafka.auto.commit=false
kafka.auto.commit.interval.ms=1000
kafka.concurrency=3
```
    --- 代码引用
```java
@Value("${kafka.consumer.enabled:false}")
private boolean consumer;

@Value("${kafka.servers:}")
private String servers;
@Value("${kafka.zookeeper.enabled:false}")
private boolean isZk;
@Value("${kafka.zookeeper.servers:}")
private String zkServers;
@Value("${kafka.topics:}")
private String topics;
@Value("${kafka.timeout:30000}")
private int timeout;

@Value("${kafka.group.id:}")
private String groupId;
@Value("${kafka.batch.commit:false}")
private boolean isBatch;
@Value("${kafka.auto.commit:false}")
private boolean autoCommit;
@Value("${kafka.auto.commit.interval.ms:1000}")
private int commitInterval;
@Value("${kafka.concurrency:3}")
private int concurrency;

@Autowired
private KafkaConsumerMessageListener listener;
@PostConstruct
public void kafkaConsumerMessageListener() {
    consumer = StringUtils.isNotBlank(System.getenv("KAFKA_CONSUMER_ENABLED"))?Boolean.parseBoolean(System.getenv("KAFKA_CONSUMER_ENABLED")):consumer;
    if (!consumer) {
        logger.info(">>>>>>>>>>> Kafka Consumer Disabled.");
        return;
    }
    logger.info(">>>>>>>>>>> Kafka Consumer config init....");
    // 此处自行写接受实现
    KafkaConsumerFactory factory = new KafkaConsumerFactory();
    factory.setServers(servers);
    factory.setRetries(retries);
    factory.setTimeout(timeout);
    factory.setTopics(topics);
    factory.setRunning(true);
    factory.setGroupId(groupId);
    factory.setBatch(isBatch);
    factory.setAutoCommit(autoCommit);
    factory.setCommitInterval(commitInterval);
    factory.setConcurrency(concurrency);
    factory.setListener(listener);
    factory.start();
}
```
>    注：消费端需实现KafkaConsumerMessageListener接口并在handle(String topic, String data)方法中实现业务逻辑

>    若autoCommit=true则自动Ack否则根据handle(topic,data)的响应结果进行是否Ack，如果不进行Ack将会重复消费

>    若isBatch=false则单条消费data为json对象，否则为批量消费data为Json对象数组

##### 单播消费或广播消费
- Kafka支持单播消费：仅一方接受消费消息其他端不消费，需配置消费端的GroupID相同
- Kafka广播消费：所有消费端接受相同的消息，需配置各消费端GroupID不相同
	
## 七. Redis服务
对Spring-Redis的操作，应用基础方式：
#### 1. 	数据操作：
    --- 配置参数
```properties
kafka.producer.enabled=false
kafka.servers=172.21.32.130:39092,172.21.32.131:19092,172.21.32.132:29092
kafka.zookeeper.enabled=true
kafka.zookeeper.servers=172.21.32.130:2183,172.21.32.131:2181,172.21.32.132:2182
kafka.topics=power_index_item_log
kafka.timeout.ms=30000
#producer
kafka.acks=all
kafka.retries=2147483647
kafka.batch.size=1048576
kafka.linger.ms=100
kafka.max.block.ms=9223372036854775807
kafka.buffer.memory=33554432
kafka.auto.flush=true
```
    --- 代码引用
```java
@Value("${kafka.producer.enabled:false}")
private boolean producer;

@Value("${kafka.servers:}")
private String servers;
@Value("${kafka.zookeeper.enabled:false}")
private boolean isZk;
@Value("${kafka.zookeeper.servers:}")
private String zkServers;
@Value("${kafka.topics:}")
private String topics;
@Value("${kafka.timeout:30000}")
private int timeout;

@Value("${kafka.acks:all}")
private String acks;
@Value("${kafka.retries:2147483647}")
private int retries;
@Value("${kafka.batch.size:1048576}")
private int batchSize;
@Value("${kafka.linger.ms:100}")
private int linger;
@Value("${kafka.max.block.ms:9223372036854775807}")
private long maxBlock;
@Value("${kafka.buffer.memory:33554432}")
private int memory;
@Value("${kafka.auto.flush:false}")
private boolean autoFlush;
@Bean
public KafkaProducerMessageListener kafkaProducerMessageListener() {
    producer = StringUtils.isNotBlank(System.getenv("KAFKA_PRODUCER_ENABLED"))?Boolean.parseBoolean(System.getenv("KAFKA_PRODUCER_ENABLED")):producer;
    if (!producer) {
        logger.info(">>>>>>>>>>> Kafka Producer Disabled.");
        return null;
    }
    logger.info(">>>>>>>>>>> Kafka Producer config init....");
    KafkaProducerMessageListener listener = new DefaultKafkaProducerMessageListener();
    KafkaProducerFactory factory = new KafkaProducerFactory();
    factory.setServers(servers);
    factory.setZk(isZk);
    factory.setZkServers(zkServers);
    factory.setRetries(retries);
    factory.setTimeout(timeout);
    factory.setTopics(topics);
    factory.setRunning(true);
    factory.setAcks(acks);
    factory.setAutoFlush(autoFlush);
    factory.setBatchSize(batchSize);
    factory.setLinger(linger);
    factory.setMaxBlock(maxBlock);
    factory.setMemory(memory);
    factory.setListener(listener);
    factory.start();
    return listener;
}
```     
      
     
      