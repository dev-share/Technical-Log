 package com.hollysys.smartfactory.common;

import org.apache.commons.text.StringEscapeUtils;

/**
 * @project SF_TargetManger_Service
 * @description 
 * @author ZhangYi
 * @date 2019/08/16 18:04:14
 * @version 1.0.0 
 * @Jdk 1.8 
 */
public class BootTest {
    /**
     * @description 
     * @author ZhangYi
     * @date 2019/08/16 18:04:14
     * @param args 
     */
    public static void main(String[] args) {
//      String itemCd = "max1".toUpperCase();
//        IndexItemFunction obj = IndexItemFunction.valueOf(IndexItemFunction.class, itemCd);
//        System.out.println(obj);
//        System.out.println("------------------------------------------------");
//        String today = DateUtils.formatDateTime(LocalDate.now(), DateUtils.SIMPLIFIED_FORMAT_DATE);
//        System.out.println(today);
//        String month = DateUtils.formatDateTime(LocalDate.now(), DateUtils.SIMPLIFIED_FORMAT_MONTH);
//        System.out.println(month);
//        String year = DateUtils.formatDateTime(LocalDate.now(), DateUtils.DEFAULT_FORMAT_YEAR);
//        System.out.println(year);
//        String yearx = LocalDate.now().getYear()+"";
//        System.out.println(yearx);
//        System.out.println("------------------------------------------------");
////        System.out.println(DateUtils.formatLocalDateTime("20190101", DateUtils.SIMPLIFIED_FORMAT_DATE));
//        LocalDate tmp = DateUtils.formatLocalDateTime("20180916", DateUtils.SIMPLIFIED_FORMAT_DATE).toLocalDate();
//        LocalDate now = LocalDate.now();
//        System.out.println(!tmp.isBefore(now));
//        String source = "aaa%+*_'~";
//        System.out.println(StringEscapeUtils.escapeXSI(source));
//        String url = "http://model-jlt-jltjm-jlt.hollicube.com/model/opcua/queryTreeNode/depth/0";
//        String body = "{\"depth\":1,\"forward\":true,\"id\":\"85\",\"relations\":[\"/0/35\",\"/0/46\",\"/0/47\"]}";
//        JSONObject params = JSON.parseObject(body);
//        String result = HttpUtils.httpRequest(url, HttpUtils.METHOD_POST, params);
//        System.out.println(result);
//        try {
//            redis();
//        } catch (InterruptedException e) {
//            // TODO Auto-generated catch block
//             e.printStackTrace();
//        }
//        Double a = 1.2d;
//        Double b = 1d;
//        BigDecimal b1 = new BigDecimal(new Double(a-b).toString());
//        System.out.println(b1.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue());
//        BaseMapper<T>
    	String keyword = "a+b-c*d/f%10=g(h\\i$j#k&L.m,n?o)p~q^r";
    	keyword=StringEscapeUtils.escapeXSI(keyword);
    	// a+b-c\*d/f\%10\=g\(h\\i\$j\#k\&L.m,n\?o\)p\~q^r
    	System.out.println(keyword);
    }

}
