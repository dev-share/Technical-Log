 package com.hollysys.smartfactory.common;

import java.time.LocalDateTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import com.hollysys.smartfactory.common.redis.factory.RedisDataFactory;
import com.hollysys.smartfactory.common.redis.factory.RedisMode;
import com.hollysys.smartfactory.common.redis.support.DefaultRedisTemplateListener;
import com.hollysys.smartfactory.common.util.DateUtils;

public class RedisDataTest {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		final RedisDataFactory factory = new RedisDataFactory();
		factory.setServers("172.21.32.102:6379");
		factory.setDatabase(10);
		factory.setMode(RedisMode.STANDALONE);
		factory.setMaxActive(8);
		factory.setMaxIdle(2);
		factory.setMaxWait(60*1000);
		factory.setMinIdle(2);
		factory.setTimeout(60*1000);
		factory.setShutdownTimeout(60*1000);
		final DefaultRedisTemplateListener listener = new DefaultRedisTemplateListener();
		factory.setListener(listener);
		factory.start();
		ScheduledExecutorService schedule = Executors.newSingleThreadScheduledExecutor();
		schedule.execute(()->{
			while(true) {
				String value = "datetime:"+DateUtils.formatDateTime(LocalDateTime.now());
				int fix = LocalDateTime.now().getSecond()%10;
				String key = "test_"+fix;
//				boolean flag = listener.ovalue().set(key, value).block();
				boolean flag = listener.set(key, value);
				System.out.println("--["+flag+"]key["+key+"]数据:"+listener.get(key));
				try {
					Thread.sleep(1*1000L);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}

}
