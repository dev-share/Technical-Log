 package com.hollysys.smartfactory.common;

import java.time.LocalDateTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import com.hollysys.smartfactory.common.redis.IRedisConsumerMessageListener;
import com.hollysys.smartfactory.common.redis.factory.RedisMode;
import com.hollysys.smartfactory.common.redis.factory.message.RedisConsumerFactory;
import com.hollysys.smartfactory.common.redis.factory.message.RedisProducerFactory;
import com.hollysys.smartfactory.common.redis.support.DefaultRedisProducerMessageListener;
import com.hollysys.smartfactory.common.util.DateUtils;

public class RedisMessageTest {
	public static void consumer() {
		@SuppressWarnings("resource")
		final RedisConsumerFactory factory = new RedisConsumerFactory();
		factory.setServers("172.21.32.102:6379");
		factory.setDatabase(5);
		factory.setMode(RedisMode.STANDALONE);
		factory.setMaxActive(8);
		factory.setMaxIdle(2);
		factory.setMaxWait(60*1000);
		factory.setMinIdle(2);
		factory.setTimeout(60*1000);
		factory.setShutdownTimeout(60*1000);
		factory.setTopics("test");
		final IRedisConsumerMessageListener listener = new IRedisConsumerMessageListener() {
			@Override
			public boolean handle(String topic, String data) {
				System.out.println("--topic:"+topic+",data:"+data);
				return false;
			}
		};
		factory.setListener(listener);
		factory.start();
	}
	public static void producer() {
		@SuppressWarnings("resource")
		final RedisProducerFactory factory = new RedisProducerFactory();
		factory.setServers("172.21.32.102:6379");
		factory.setDatabase(5);
		factory.setMode(RedisMode.STANDALONE);
		factory.setMaxActive(8);
		factory.setMaxIdle(2);
		factory.setMaxWait(60*1000);
		factory.setMinIdle(2);
		factory.setTimeout(60*1000);
		factory.setShutdownTimeout(60*1000);
		factory.setTopics("test");
		final DefaultRedisProducerMessageListener listener = new DefaultRedisProducerMessageListener();
		factory.setListener(listener);
		factory.start();
		ScheduledExecutorService schedule = Executors.newSingleThreadScheduledExecutor();
		schedule.execute(()->{
			while(true) {
				String value = "sub/pub datetime:"+DateUtils.formatDateTime(LocalDateTime.now());
				listener.send("test", value);
				try {
					Thread.sleep(1*1000L);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					 e.printStackTrace();
				}
			}
		});
		
	}
	public static void main(String[] args) {
		consumer();
		producer();
	}
}
