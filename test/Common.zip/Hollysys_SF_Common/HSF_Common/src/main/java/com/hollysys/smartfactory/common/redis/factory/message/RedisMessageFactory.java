package com.hollysys.smartfactory.common.redis.factory.message;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.RedisSerializationContext.RedisSerializationContextBuilder;

import com.alibaba.fastjson.support.spring.FastJsonRedisSerializer;
import com.hollysys.smartfactory.common.redis.factory.AbstractRedisFactory;

/**
 * @decription Redis订阅/消费工厂
 * @author yi.zhang
 * @time 2019/09/18 08:44:52
 * @since 1.0
 * @jdk 1.8
 */
public abstract class RedisMessageFactory extends AbstractRedisFactory {
    /**
     * Redis默认主题
     */
    public static final String REDIS_DEFAULT_TOPIC = "REDIS_DEFAULT_TOPIC";
    protected String[] topics;
    public void setTopics(String topics) {
        this.topics = StringUtils.isBlank(topics)?new String[]{REDIS_DEFAULT_TOPIC}:topics.split(",");
    }
    /**
     * @decription Redis消息序列化
     * @author yi.zhang
     * @return 
     * @time 2017年6月2日 下午2:15:57
     */
    public RedisSerializationContext<String, String> serializer() {
        FastJsonRedisSerializer<String> fastjson = new FastJsonRedisSerializer<>(String.class);
        RedisSerializationContextBuilder<String, String> serialize = RedisSerializationContext.<String,String>newSerializationContext();
        serialize.hashKey(fastjson);
        serialize.hashValue(fastjson);
        serialize.key(fastjson);
        serialize.value(fastjson);
        serialize.string(fastjson);
        return serialize.build();
    }
}
