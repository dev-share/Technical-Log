package com.hollysys.smartfactory.common.listener;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * @Description: SpringContextGlobalHolder
 * @Param:
 * @return:
 * @Author: ZhangYi
 * @Date: 2019/8/12
 */
@Component("gctx")
public class SpringContextGlobalHolder implements ApplicationContextAware {

    private static ApplicationContext ctx = null;

    /**
     * @Description: 设置ApplicationContext
     * @Param: [applicationContext]
     * @return: void
     * @Author: ZhangYi
     * @Date: 2019/8/12
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        ctx = applicationContext;
    }
    /**
     * @description 添加上下文
     * @author ZhangYi
     * @date 2019/08/23 13:43:34
     * @param context
     * @return
     */
    public static void setContext(ApplicationContext context) {
        if(ctx==null) {
           ctx = context;
        }
    }
    /**
     * @Description: 获取Context
     * @Param: []
     * @return: org.springframework.context.ApplicationContext
     * @Author: ZhangYi
     * @Date: 2019/8/12
     */
    public static ApplicationContext getContext() {
        return ctx;
    }

    /**
     * @Description: 获取getBean
     * @Param: [bean]
     * @return: T
     * @Author: ZhangYi
     * @Date: 2019/8/12
     */
    public static <T> T getBean(Class<T> bean) {
        return ctx.getBean(bean);
    }
    /**
     * @Description: 获取getBean
     * @Param: [bean]
     * @return: java.lang.Object
     * @Author: ZhangYi
     * @Date: 2019/8/12
     */
    public static <T> Object getBean(String bean) {
        return ctx.getBean(bean);
    }
}
