package com.hollysys.smartfactory.common.service;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hollysys.smartfactory.common.mapper.BaseMapper;
import com.hollysys.smartfactory.common.model.req.PageReq;

import tk.mybatis.mapper.entity.Example;

@Transactional
public abstract class BaseService<T> {
    protected BaseMapper<T> mapper;

    public abstract void setMapper(BaseMapper<T> mapper);

    /**
     * @description 分页
     * 
     * @author ZhangYi
     * @date 2019-03-26 09:42:48
     * @param req
     */
    protected void page(PageReq req) {
        PageHelper.startPage(req.getPage(), req.getPageSize());
    }
    
    protected PageInfo<T> findAllByPage(Example example,PageReq req){
        int total = mapper.selectCountByExample(example);
        int pageNum = req != null && req.getPage() != null ? req.getPage() : 1;
        int pageSize = req != null && req.getPageSize() != null ? req.getPageSize() : -1;
        int offset = req != null && req.getOffset() != null ? req.getOffset()-1 : 0;
        Page<T> page = new Page<>(pageNum,pageSize);
        page.setTotal(total);
        List<T> list = mapper.selectByExampleAndRowBounds(example, new RowBounds(offset, pageSize));
        if (list != null && !list.isEmpty()) {
            page.addAll(list);
        }
        return new PageInfo<>(page);
    }
    
    protected PageInfo<T> findAllByPage(Example example,int pageNum,int pageSize){
        int total = mapper.selectCountByExample(example);
        int limit = pageSize>0 ? pageSize : Integer.MAX_VALUE;
        pageNum = pageNum > 0 ? pageNum : 1;
        int offset = (pageNum - 1) * limit + 1;
        Page<T> page = new Page<>(pageNum,pageSize);
        page.setTotal(total);
        List<T> list = mapper.selectByExampleAndRowBounds(example, new RowBounds(offset, pageSize));
        if (list != null && !list.isEmpty()) {
            page.addAll(list);
        }
        return new PageInfo<>(page);
    }
}
