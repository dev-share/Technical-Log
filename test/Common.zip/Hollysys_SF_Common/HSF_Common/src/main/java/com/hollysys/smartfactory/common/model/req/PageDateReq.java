package com.hollysys.smartfactory.common.model.req;

import java.beans.Transient;
import java.time.LocalDateTime;

import javax.validation.constraints.AssertTrue;

import org.apache.commons.lang.StringUtils;
import org.springframework.validation.BindException;

import com.hollysys.smartfactory.common.exception.CustomException;
import com.hollysys.smartfactory.common.util.DateUtils;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @project SF_Common_Service
 * @description 前台请求体(包含时间段的分页)
 * @author ZhangYi
 * @date 2019/09/23 16:48:43
 * @version 1.0.0 
 * @Jdk 1.8
 */
@ApiModel
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
public class PageDateReq extends PageReq {
    private static final long serialVersionUID = -6204110494896686981L;
    @ApiParam(value = "开始时间(格式:yyyy-MM-dd或yyyy-MM-dd HH:mm:ss)", format = "yyyy-MM-dd HH:mm:ss")
    private String startTime;
    @ApiParam(value = "开始时间(格式:yyyy-MM-dd或yyyy-MM-dd HH:mm:ss)", format = "yyyy-MM-dd HH:mm:ss")
    private String endTime;

    @Transient
    public LocalDateTime getStartDate() throws CustomException {
        LocalDateTime dateTime = format(startTime, true);
        return dateTime;
    }

    @Transient
    public LocalDateTime getEndDate() throws BindException, CustomException {
        LocalDateTime dateTime = format(endTime, false);
        return dateTime;
    }

    @AssertTrue(message = "开始时间必须小于结束时间!")
    private boolean validTime() {
        boolean flag = true;
        if (StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime) && startTime.compareTo(endTime) > 0) {
            flag = false;
        }
        return flag;
    }

    /**
     * @description 日期格式化 作者: ZhangYi 时间: 2019年3月15日 上午10:52:42 参数: (参数列表)
     * 
     * @param dateTimeStr 时间字符串(兼容格式:yyyy-MM-dd或yyyy-MM-dd HH:mm:ss或yyyy/MM/dd或yyyy/MM/dd HH:mm:ss或时间戳)
     * @param isFirstTime 日开始时间或结束时间
     * @return
     * @throws Exception
     */
    private LocalDateTime format(String dateTimeStr, boolean isFirstTime) throws CustomException {
        LocalDateTime dateTime = null;
        if (StringUtils.isNotBlank(dateTimeStr)) {
            if (dateTimeStr.contains(DateUtils.SPLIT_DATE) || dateTimeStr.contains(DateUtils.SPLIT_ISO_DATE)) {
                dateTimeStr = dateTimeStr.replaceAll(DateUtils.SPLIT_ISO_DATE, DateUtils.SPLIT_DATE);
                if (DateUtils.DEFAULT_FORMAT_DATE.length() == dateTimeStr.length()) {
                    dateTimeStr += isFirstTime ? " 00:00:00" : " 23:59:59";
                }
                dateTime = DateUtils.formatLocalDateTime(dateTimeStr);
            } else {
                long standard = System.currentTimeMillis() - 10 * 365 * DateUtils.MILLIS_PER_DAY;
                long timestamp = Long.parseLong(dateTimeStr);
                // 防止格式化后为格林治时间起始时间
                if (timestamp > standard) {
                    dateTime = DateUtils.dateToDateTime(timestamp);
                } else {
                    throw new CustomException("--时间格式不正确!");
                }
            }
        }
        return dateTime;
    }
}
