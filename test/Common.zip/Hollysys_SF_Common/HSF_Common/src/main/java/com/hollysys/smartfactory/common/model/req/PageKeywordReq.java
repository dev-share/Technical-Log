package com.hollysys.smartfactory.common.model.req;

import javax.validation.constraints.AssertTrue;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @project SF_Common_Service
 * @description 分页关键字搜索请求
 * @author ZhangYi
 * @date 2019/09/23 16:48:43
 * @version 1.0.0 
 * @Jdk 1.8
 */
@ApiModel
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
public class PageKeywordReq extends PageReq {
    private static final long serialVersionUID = 4860613471830272307L;
    @ApiParam(value = "关键字")
    protected String keyword;

    @AssertTrue
    private boolean isTransform() {
        if (StringUtils.isNotBlank(keyword)) {
            keyword = StringEscapeUtils.escapeXSI(keyword);
//            keyword = keyword.replaceAll("$", "/$").replaceAll("#", "/#");
        }
        return true;
    }
}
