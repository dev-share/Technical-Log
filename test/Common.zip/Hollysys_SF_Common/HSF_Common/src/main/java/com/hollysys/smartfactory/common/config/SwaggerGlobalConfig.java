package com.hollysys.smartfactory.common.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.hollysys.smartfactory.common.constant.GlobalConstant;

import io.swagger.annotations.Api;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.Parameter;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @project SF_Common_Service
 * @description Swagger 配置
 * @author ZhangYi
 * @date 2019/09/23 16:59:46
 * @version 1.0.0 
 * @Jdk 1.8
 */
@Configuration
@EnableSwagger2
public class SwaggerGlobalConfig {
    /**
     * 跨域过滤器
     */
    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration conf = new CorsConfiguration();
        conf.addAllowedOrigin("*");
        conf.addAllowedHeader("*");
        conf.addAllowedMethod("*");
        conf.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", conf);
        return new CorsFilter(source);
    }
    
    @Bean
    public Docket docket() {
        ApiInfoBuilder api = new ApiInfoBuilder();
        api.title(GlobalConstant.SYSTEM_NAME);
        api.version(GlobalConstant.SYSTEM_VERSION);
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(api.build())
                .select()
                .apis(RequestHandlerSelectors.withClassAnnotation(Api.class))
                .paths(PathSelectors.any())
                .build()
                .globalOperationParameters(buildToken());
    }

    @Bean
    public SecurityScheme apiKey() {
        return new ApiKey("access_token", "accessToken", "header");
    }

    private List<Parameter> buildToken() {
        ParameterBuilder token = new ParameterBuilder();
        if(SystemGlobalConfig.SYSTEM_AUTHORIZATION) {
            token.name(GlobalConstant.SYSTEM_HEADER_TOKEN).description("令牌").modelRef(new ModelRef("string")).parameterType("header").required(false).build();
        }
        List<Parameter> params = new ArrayList<>();
        params.add(token.build());
        return params;
    }
}
