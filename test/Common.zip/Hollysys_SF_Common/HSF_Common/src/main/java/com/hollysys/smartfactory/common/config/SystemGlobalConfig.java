package com.hollysys.smartfactory.common.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * @project SF_Common_Service
 * @description 系统配置(获取properties文件配置)
 *
 * @author ZhangYi 时间: 2019年3月18日 下午5:31:28 版本: v1.0 JDK: 1.8
 */
@Configuration("glocal")
public class SystemGlobalConfig {
    /**
     * 系统debug模式
     */
    public volatile static boolean SYSTEM_DEBUG_VERBOSE = false;
    /**
     * 系统是否开启认证模式
     */
    public volatile static boolean SYSTEM_AUTHORIZATION = true;
    /**
     * 系统是否开启认证模式
     */
    public volatile static String SYSTEM_HOST = "127.0.0.1";
    
    @Value("${authorization.enabled:true}")
    private void setLabelSubscribedEnabled(String enabled) {
        enabled = StringUtils.isNotBlank(System.getenv("AUTHORIZATION_ENABLED")) ? System.getenv("AUTHORIZATION_ENABLED") : enabled;
        SYSTEM_AUTHORIZATION = Boolean.valueOf(enabled);
    }
}
