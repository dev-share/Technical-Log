package com.hollysys.smartfactory.common.constant;

/**
 * @project SF_Common_Service
 * @description 常量
 * 
 * @author ZhangYi
 * @date 2019-04-28 15:40:00
 * @version v1.0
 * @Jdk 1.8
 */
public class GlobalConstant {
    /**
     * 默认域目录
     */
    public static final String HOLLYSYS_DEFAULT_DOMAIN = "com.hollysys.smartfactory";
    /**
     * 域目录
     */
    public static final String HOLLYSYS_DOMAIN = "com.hollysys.smart.factory";
    /**
     * 系统名称
     */
    public static final String SYSTEM_NAME = "后台API";
    /**
     * 系统版本
     */
    public static final String SYSTEM_VERSION = "1.0.0";
    /**
     * 系统鉴权Token
     */
    public static final String SYSTEM_HEADER_TOKEN = "Authorization";

}
