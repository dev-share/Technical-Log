package com.hollysys.smartfactory.common.redis.support;

import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Range;
import org.springframework.data.redis.connection.RedisZSetCommands.Limit;
import org.springframework.data.redis.core.DefaultTypedTuple;
import org.springframework.data.redis.core.ReactiveGeoOperations;
import org.springframework.data.redis.core.ReactiveHashOperations;
import org.springframework.data.redis.core.ReactiveHyperLogLogOperations;
import org.springframework.data.redis.core.ReactiveListOperations;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.core.ReactiveSetOperations;
import org.springframework.data.redis.core.ReactiveValueOperations;
import org.springframework.data.redis.core.ReactiveZSetOperations;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;
import org.springframework.data.redis.core.types.Expiration;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair;

import com.alibaba.fastjson.JSON;
import com.hollysys.smartfactory.common.exception.CustomException;
import com.hollysys.smartfactory.common.redis.IRedisTemplateListener;

import reactor.core.publisher.Flux;

/**
 * @project HSF_Common
 * @description Redis默认数据操作
 * @author ZhangYi
 * @date 2019/09/30 12:46:02
 * @version 1.0.0
 * @Jdk 1.8
 */
public class DefaultRedisTemplateListener implements IRedisTemplateListener {
    private static final Logger logger = LoggerFactory.getLogger(DefaultRedisTemplateListener.class);
    public static final String DEFALUT_LOCK_PREFIX = "_lock_";
    protected ReactiveRedisTemplate<String, Object> template;
    @Override
    public void setRedisTemplate(ReactiveRedisTemplate<String, Object> template) {
        this.template = template;
    }
    public RedisSerializationContext<String, Object> serialization(){
        return template.getSerializationContext();
    }
    
    public ReactiveSetOperations<String, Object> oset(){
        return template.opsForSet();
    }
    public ReactiveZSetOperations<String, Object> ozset(){
        return template.opsForZSet();
    }
    public ReactiveHashOperations<String,String, Object> ohash(){
        return template.opsForHash();
    }
    public ReactiveListOperations<String, Object> olist(){
        return template.opsForList();
    }
    public ReactiveValueOperations<String, Object> ovalue(){
        return template.opsForValue();
    }
    public ReactiveHyperLogLogOperations<String, Object> ohyperLogLog(){
        return template.opsForHyperLogLog();
    }
    public ReactiveGeoOperations<String, Object> ogeo(){
        return template.opsForGeo();
    }
    /**
     * @description 检查模板
     * @author ZhangYi
     * @date 2019/10/09 15:01:09
     * @throws CustomException
     */
    private void check() throws CustomException{
        if(template==null) {
            throw new CustomException("--Redis Not Available");
        }
    }
    /**
     * 指定缓存失效时间
     * @param key 键
     * @param time 时间(秒)
     * @return
     */
    public boolean expire(String key, long time) {
        boolean flag = false;
        try {
            check();
            if (time > 0) {
                flag = template.expire(key, Duration.ofSeconds(time)).block();
            }else {
                flag = true;
            }
        } catch (Exception e) {
            logger.error("--redis expire error !",e);
            return false;
        }
        return flag;
    }

    /**
     * 根据key 获取过期时间
     * 
     * @param key 键 不能为null
     * @return 时间(秒) 返回0代表为永久有效
     */

    public long getExpire(String key) {
        check();
        long time = template.getExpire(key).block().getSeconds();
        return time;
    }

    /**
     * 
     * 判断key是否存在
     * 
     * @param key 键
     * 
     * @return true 存在 false不存在
     * 
     */

    public boolean hasKey(String key) {
        try {
            check();
            return template.hasKey(key).block();
        } catch (Exception e) {
            logger.error("--redis expire error !",e);
            return false;
        }
    }
    public <T> boolean set(String key, T value) {
        return set(key, value instanceof String?(String)value:JSON.toJSONString(value),0L);
    }
    /**
             *      描述: Redis设置一个值
     * 		template.execute(connection->{
     *     		SerializationPair<String> serializer = template.getSerializationContext().getStringSerializationPair();
     *     		if(timeout>0) {
     *     			return connection.stringCommands().setEX(serializer.getWriter().write(key), serializer.getWriter().write(value), Expiration.seconds(timeout));
     *     		}else {
     *     			return connection.stringCommands().setNX(serializer.getWriter().write(key), serializer.getWriter().write(value));
     *     		}
     *     	});
     * @author ZhangYi
     * @date 2019-11-05 09:01:01
     * @param key
     * @param value
     * @param timeout Seconds of Expire
     * @return
     */
    public boolean set(String key, String value, long timeout) {
    	check();
//    	if(timeout>0) {
//    		return ovalue().set(key, value, Duration.ofSeconds(timeout)).block();
//    	}else {
//    		return ovalue().set(key, value).block();
//    	}
    	Flux<Boolean> mono = template.execute(connection->{
    		SerializationPair<String> serializer = template.getSerializationContext().getStringSerializationPair();
    		if(timeout>0) {
    			return connection.stringCommands().setEX(serializer.getWriter().write(key), serializer.getWriter().write(value), Expiration.seconds(timeout));
    		}else {
    			return connection.stringCommands().setNX(serializer.getWriter().write(key), serializer.getWriter().write(value));
    		}
    	});
    	return mono.blockFirst();
    }

    @SuppressWarnings("unchecked")
	public <T> T get(String key, Class<T> clazz) {
    	String value = get(key);
        return clazz.isAssignableFrom(String.class)?(T)value:JSON.parseObject(value, clazz);
    }
    /**
       *  描述:  获取值
     *      SerializationPair<String> serializer = template.getSerializationContext().getStringSerializationPair();
     *     	ByteBuffer buffer = template.execute(connection-> connection.stringCommands().get(serializer.getWriter().write(key))).blockFirst();
     *     	return serializer.getReader().read(buffer)
     * @author ZhangYi
     * @date 2019-12-23 18:48:30
     * @param key
     * @return
     */
    public String get(String key) {
    	check();
//    	return (String)ovalue().get(key).block();
    	SerializationPair<String> serializer = template.getSerializationContext().getStringSerializationPair();
    	ByteBuffer buffer = template.execute(connection-> connection.stringCommands().get(serializer.getWriter().write(key))).blockFirst();
    	return serializer.getReader().read(buffer);
    }
    /*****************************************************************************************************/
    /************************************************Set操作***********************************************/
    /*****************************************************************************************************/
    /**
     * @description 向key中添加集合值
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @param values 集合值
     * @return
     */
    public boolean sadd(String key, Object... values) {
        check();
        long total = oset().add(key, values).block();
        return total>0;
    }
    /**
     * @description 删除key及其集合数据
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @return
     */
    public boolean sdelete(String key) {
        check();
        return oset().delete(key).block();
    }

    /**
     * @description 获取Key中集合值
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @return
     */
    public List<Object> members(String key) {
        check();
        return oset().members(key).collectList().block();
    }

    /**
     * @description 移除key中的集合值
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @param values 集合值
     * @return
     */
    public boolean sremove(String key, Object... values) {
        check();
        long total = oset().remove(key, values).block();
        return total>0?true:false;
    }


    /**
     * @description 弹出key的值
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @return
     */
    public Object spop(String key) {
        check();
        return oset().pop(key).block();
    }

    /**
     * @description 判断值是否在Key中存在
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @param value 值
     * @return
     */
    public boolean ismember(String key, Object value) {
        check();
        return oset().isMember(key, value).block();
    }
    /*****************************************************************************************************/
    /************************************************ZSet操作***********************************************/
    /*****************************************************************************************************/
    /**
     * @description 单条插入
     * @author ZhangYi
     * @date 2019/10/09 17:56:41
     * @param key 键
     * @param score 排序
     * @param value 值
     * @return
     */
    public boolean zadd(String key, double score, Object value) {
        check();
        return ozset().add(key, value, score).block();
    }

    /**
     * @description 单条插入
     * @author ZhangYi
     * @date 2019/10/09 17:56:41
     * @param key 键
     * @param score 排序
     * @param value 值
     * @return
     */
    public boolean zadd(String key, SortedMap<Double,Object> map) {
        check();
        final Collection<TypedTuple<Object>> tuples = new ArrayList<>();
        for (Map.Entry<Double,Object> obj : map.entrySet()) {
            tuples.add(new DefaultTypedTuple<Object>(obj.getValue(), obj.getKey())); 
        }
        ozset().addAll(key, tuples);
        return true;
    }

    /**
     * @description 移除key中的集合值
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @param values 集合值
     * @return
     */
    public boolean zremove(String key, Object... values) {
        check();
        long total = ozset().remove(key, values).block();
        return total>0;
    }

    /**
     * @description 集合大小
     * @author ZhangYi
     * @date 2019/10/09 17:42:10
     * @param key   键
     * @return
     */
    public long zsize(String key) {
        check();
        return ozset().size(key).block();
    }

    /**
     * @description 取集合
     * @author ZhangYi
     * @date 2019/10/11 13:38:17
     * @param key   键
     * @param pageNo 页编号
     * @param pageSize 页数量
     * @return
     */
    public List<Object> zrange(String key, int pageNo, int pageSize) {
        check();
        int offset = pageNo<1?0:(pageNo-1)*pageSize;
        return ozset().rangeByLex(key, Range.unbounded(),Limit.limit().offset(offset).count(pageSize)).collectSortedList().block();
    }
    /*****************************************************************************************************/
    /************************************************锁操作***********************************************/
    /*****************************************************************************************************/
    /**
     * 锁表
     * @param key
     *            键
     * @return
     */
    public synchronized boolean lock(String key) {
        check();
        while (true) {
            boolean exist = ovalue().size(DEFALUT_LOCK_PREFIX+key).block()>0;
            if (exist) {
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    logger.error("--redis lock error !",e);
                }
            } else {
                break;
            }
        }
        ovalue().set(DEFALUT_LOCK_PREFIX+key, key, Duration.ofMillis(30));
        return true;
    }

    /**
     * 释放锁定
     * @param key
     *            键
     * @return
     */
    public boolean unlock(String key) {
        check();
        ovalue().delete(DEFALUT_LOCK_PREFIX+key);
        return true;
    }
}
