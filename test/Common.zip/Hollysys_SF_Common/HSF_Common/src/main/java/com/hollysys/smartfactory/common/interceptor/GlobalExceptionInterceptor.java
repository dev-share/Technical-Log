package com.hollysys.smartfactory.common.interceptor;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.hollysys.smartfactory.common.bean.AjaxResult;
import com.hollysys.smartfactory.common.exception.CustomException;

/**
 * @project SF_Common_Service
 * @description 异常信息拦截
 * @author ZhangYi
 * @date 2019/09/23 17:07:04
 * @version 1.0.0 
 * @Jdk 1.8
 */
@RestControllerAdvice
public class GlobalExceptionInterceptor {
    private static Logger logger = LoggerFactory.getLogger(GlobalExceptionInterceptor.class);

    /**
     * @description 异常信息拦截
     * 
     * @author ZhangYi
     * @date 2019-04-02 10:59:17
     * @param e 异常信息
     * @return
     */
    @ExceptionHandler(value = {CustomException.class, MethodArgumentNotValidException.class, BindException.class, RuntimeException.class, Exception.class, Throwable.class})
    public ResponseEntity<AjaxResult> handleException(Exception e) {
        logger.error("-------------------------------------------------------");
        int status = HttpStatus.OK.value();
        AjaxResult result = new AjaxResult(AjaxResult.AJAX_STATUS_ERROR);
        e = (e == null ? new CustomException("Global Exception") : e);
        if (e instanceof CustomException) {
            CustomException cause = (CustomException)e;
            logger.error("GlobalHandle CustomException", cause);
            String message = cause.getMessage();
            if(StringUtils.isBlank(message)) {
            	message = cause.printErrors();
            }
            result.setMessage(message);
            status = cause.getStatus();
        } else if (e instanceof BindException || e instanceof MethodArgumentNotValidException) {
            BindingResult cause = null;
            if (e instanceof BindException) {
                cause = (BindException)e;
                logger.error("GlobalHandle BindException", e);
            } else {
                MethodArgumentNotValidException ex = ((MethodArgumentNotValidException)e);
                cause = ex.getBindingResult();
                logger.error("GlobalHandle MethodArgumentNotValidException", e);
            }
            if (cause.getFieldError() == null || cause.getFieldError().getDefaultMessage() == null) {
                result.setMessage(e.getMessage());
            } else {
                result.setMessage(cause.getFieldError().getDefaultMessage());
            }
        } else if (e instanceof RuntimeException) {
            RuntimeException cause = (RuntimeException)e;
            logger.error("GlobalHandle RuntimeException", cause);
            result.setMessage(cause.getMessage());
        } else {
            logger.error("GlobalHandle Exception", e);
            result.setMessage(e.getMessage());
        }
        return new ResponseEntity<>(result,status!=HttpStatus.OK.value()?HttpStatus.INTERNAL_SERVER_ERROR:HttpStatus.OK);  
    }
}
