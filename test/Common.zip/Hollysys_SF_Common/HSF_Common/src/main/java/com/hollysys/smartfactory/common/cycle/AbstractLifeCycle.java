package com.hollysys.smartfactory.common.cycle;


import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
/**
 *   项目: sf-common
 *   描述: 服务生命周期
* @author ZhangYi
* @date 2019-10-25 12:30:07
 *   版本: v1.0
* JDK: 1.8
*/
public abstract class AbstractLifeCycle implements InitializingBean, DisposableBean,LifeCycle{
	@Override
	public void afterPropertiesSet() throws Exception {
		
	}
	@Override
	public void destroy() throws Exception {
		close();
	}
}
