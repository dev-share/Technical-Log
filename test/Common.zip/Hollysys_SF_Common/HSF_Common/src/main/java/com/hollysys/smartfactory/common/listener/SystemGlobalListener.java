package com.hollysys.smartfactory.common.listener;

import java.net.SocketException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.context.WebApplicationContext;

import com.hollysys.smartfactory.common.config.SystemGlobalConfig;
import com.hollysys.smartfactory.common.constant.GlobalConstant;
import com.hollysys.smartfactory.common.util.HttpUtils;

/**
 * @project SF_Common_Service
 * @description 系统监听器
 * @author ZhangYi
 * @date 2019/09/23 16:46:02
 * @version 1.0.0 
 * @Jdk 1.8
 */
@EnableAutoConfiguration
@SpringBootConfiguration
@ComponentScan(basePackages= {GlobalConstant.HOLLYSYS_DEFAULT_DOMAIN})
@WebListener
public class SystemGlobalListener implements ServletContextListener {
    private static Logger logger = LoggerFactory.getLogger(SystemGlobalListener.class);

    @Override
    public void contextInitialized(ServletContextEvent ctx) {
        logger.info("-----------------系统Listener参数初始化-----------------");
        try {
			SystemGlobalConfig.SYSTEM_DEBUG_VERBOSE = Boolean.parseBoolean(System.getenv("DEBUG_VERBOSE"));
			ServletContext servletContext = ctx.getServletContext();
			ApplicationContext context = (ApplicationContext) servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
			SpringContextGlobalHolder.setContext(context);
			SystemGlobalConfig.SYSTEM_HOST = HttpUtils.getLocalHost();
		} catch (SocketException e) {
			logger.error("--Global System init error !", e);
		}
    }

    @Override
    public void contextDestroyed(ServletContextEvent ctx) {
        logger.info("-----------------系统Listener销毁-----------------");
    }
}
