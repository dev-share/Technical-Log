package com.hollysys.smartfactory.common.config;

import java.util.Collections;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.interceptor.NameMatchTransactionAttributeSource;
import org.springframework.transaction.interceptor.RollbackRuleAttribute;
import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
import org.springframework.transaction.interceptor.TransactionInterceptor;

/**
 * @project SF_Common_Service
 * @description 系统事务
 * 
 * @author ZhangYi
 * @date 2019-05-20 15:41:42
 * @version v1.0
 * @Jdk 1.8
 */
@Aspect
@EnableTransactionManagement
@Configuration
public class TransactionAdviceConfig {
    private static final String AOP_POINTCUT_EXPRESSION = "execution(* * ..service..*(..))";
    @Autowired
    private PlatformTransactionManager transactionManager;

    /**
     * @description 事务过虑链
     * 
     * @author ZhangYi
     * @date 2019-05-20 15:42:03
     * @return
     */
    @Bean
    public TransactionInterceptor txAdvice() {
        /* 只读事务，不做更新操作 */
        RuleBasedTransactionAttribute nosupports = new RuleBasedTransactionAttribute();
        nosupports.setReadOnly(true);
        nosupports.setPropagationBehavior(TransactionDefinition.PROPAGATION_NOT_SUPPORTED);
        /* 只读事务，不做更新操作 */
        RuleBasedTransactionAttribute supports = new RuleBasedTransactionAttribute();
        supports.setReadOnly(true);
        supports.setPropagationBehavior(TransactionDefinition.PROPAGATION_SUPPORTS);
        /* 当前存在事务就使用当前事务，当前不存在事务就创建一个新的事务 */
        RuleBasedTransactionAttribute required = new RuleBasedTransactionAttribute();
        required.setRollbackRules(Collections.singletonList(new RollbackRuleAttribute(Exception.class)));
        required.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        // REQUIRED.setTimeout(TX_METHOD_TIMEOUT);

        NameMatchTransactionAttributeSource source = new NameMatchTransactionAttributeSource();
        source.addTransactionalMethod("add*", required);
        source.addTransactionalMethod("save*", required);
        source.addTransactionalMethod("insert*", required);
        source.addTransactionalMethod("update*", required);
        source.addTransactionalMethod("upsert*", required);
        source.addTransactionalMethod("delete*", required);
        source.addTransactionalMethod("remove*", required);
        source.addTransactionalMethod("modify*", required);
        source.addTransactionalMethod("batch*", required);

        source.addTransactionalMethod("get*", supports);
        source.addTransactionalMethod("find*", supports);
        source.addTransactionalMethod("count*", supports);
        source.addTransactionalMethod("load*", supports);
        source.addTransactionalMethod("exist*", supports);
        source.addTransactionalMethod("search*", supports);

        source.addTransactionalMethod("*", nosupports);
        TransactionInterceptor txAdvice = new TransactionInterceptor(transactionManager, source);
        return txAdvice;
    }

    /**
     * @description 事务通知
     * 
     * @author ZhangYi
     * @date 2019-05-20 15:42:40
     * @return
     */
    @Bean
    public Advisor txAdviceAdvisor() {
        AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
        pointcut.setExpression(AOP_POINTCUT_EXPRESSION);
        return new DefaultPointcutAdvisor(pointcut, txAdvice());
    }
}