package com.hollysys.smartfactory.common.redis.factory.message;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.Executors;

import org.apache.commons.compress.utils.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.Topic;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.util.ObjectUtils;

import com.hollysys.smartfactory.common.config.SystemGlobalConfig;
import com.hollysys.smartfactory.common.redis.IRedisConsumerMessageListener;

/**
 * @decription Redis消费工厂
 * @author yi.zhang
 * @time 2019/09/18 08:44:52
 * @since 1.0
 * @jdk 1.8
 */
public class RedisConsumerFactory extends RedisMessageFactory {
    private static final Logger logger = LoggerFactory.getLogger(RedisConsumerFactory.class);
	private IRedisConsumerMessageListener listener = null;
	private RedisMessageListenerContainer service;
	private boolean isPattern;
	private long waitingTime = 2*1000L;
	private long recoveryInterval = 5*1000L;
	public void setPattern(boolean isPattern) {
		this.isPattern = isPattern;
	}
	public void setListener(IRedisConsumerMessageListener listener) {
        this.listener = listener;
    }
	/**
	 * Specify the max time to wait for subscription registrations, in milliseconds. The default is 2000ms, thatis, 2 second.
	 * @author ZhangYi
	 * @date 2019-12-24 16:20:10
	 * @param waitingTime
	 */
	public void setMaxSubWaitingTime(long waitingTime) {
		this.waitingTime = waitingTime;
	}
	/**
	 *  Specify the interval between recovery attempts, in milliseconds. The default is 5000 ms, that is, 5 seconds.
	 * @author ZhangYi
	 * @date 2019-12-24 16:18:19
	 * @param interval
	 */
	public void setRecoveryInterval(long recoveryInterval) {
		this.recoveryInterval = recoveryInterval;
	}
    /**
	 * @decription 初始化配置
	 * @author yi.zhang
	 * @time 2017年6月2日 下午2:15:57
	 */
	public void init() {
		try {
		    super.build();
		    topics = (topics==null||topics.length<1)?new String[]{REDIS_DEFAULT_TOPIC}:topics;
		    List<Topic> list = Lists.newArrayList();
		    for (String name : topics) {
		    	Topic topic = isPattern?new PatternTopic(name):new ChannelTopic(name);
		    	list.add(topic);
			}
			MessageListenerAdapter adapter = new MessageListenerAdapter();
			adapter.setDelegate((MessageListener)(message, pattern)-> {
				if (message == null || ObjectUtils.isEmpty(message.getBody())) {
					return;
				}
				byte[] channel = ObjectUtils.isEmpty(message.getChannel())?pattern:message.getChannel();
				byte[] msg = message.getBody();
				try {
					String topic = new String(channel, StandardCharsets.UTF_8.name());
					String data = new String(msg, StandardCharsets.UTF_8.name());
					boolean flag = listener.handle(topic, data);
					if(!flag&&SystemGlobalConfig.SYSTEM_DEBUG_VERBOSE) {
						logger.warn("--redis consumer sub fail{topic:{},data:{}}!",topic,data);
					}
					Thread.sleep(10l);
				} catch (Exception e) {
					logger.error("-----Redis handle Message Error-----", e);
				}
			});
			service = new RedisMessageListenerContainer();
			service.setConnectionFactory(factory);
			service.setMaxSubscriptionRegistrationWaitingTime(waitingTime);
			service.setRecoveryInterval(recoveryInterval);
			service.addMessageListener(adapter, list);
			service.afterPropertiesSet();
			service.start();
		} catch (Exception e) {
			logger.error("-----Redis Config init Error-----", e);
		}
	}
	@Override
	public void start() {
		boolean delay = delay();
		if(!delay) {
			init();
		}
	    Executors.newSingleThreadExecutor().execute(() -> {
	        while (running) {
	            try {
	                if(listener==null) {
	                   logger.error("-----Redis must have at least one consumer!");
	                   break; 
	                }
	                if(service==null||!service.isRunning()) {
	                	reconnect(); 
	                }
	                Thread.sleep(1000l);
	            } catch (InterruptedException e) {
	                logger.error("--Redis Interrupted...",e);
	                Thread.currentThread().interrupt();
	            }
	        }
	    });
	}
	@Override
	public void reconnect() {
		close();
		init();
	}
	@Override
	public boolean delay() {
		 return true;
	}
	/**
	 * 关闭服务
	 */
	@Override
	public void close() {
		super.close();
		if (service != null) {
		    service.stop();
		}
	}
}
