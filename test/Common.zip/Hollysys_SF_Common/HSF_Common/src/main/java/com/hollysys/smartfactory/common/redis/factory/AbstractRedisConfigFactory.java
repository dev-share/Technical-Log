 package com.hollysys.smartfactory.common.redis.factory;

import java.net.URI;
import java.util.List;

import org.apache.commons.compress.utils.Lists;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.util.StringUtils;

/**
 * @project SF_TargetCalculate_Service
 * @description Redis配置工厂
 * @author ZhangYi
 * @date 2019/09/17 19:25:36
 * @version 1.0.0 
 * @Jdk 1.8 
 */
public abstract class AbstractRedisConfigFactory {
    /**
     * CPU数量
     */
    public static final int SYS_CORE = Runtime.getRuntime().availableProcessors();
    private static final String REDIS_DEFAULT_HOST = "127.0.0.1";
    private static final int REDIS_DEFAULT_PORT = 6379;
    private String url;
    private String servers = REDIS_DEFAULT_HOST+":"+REDIS_DEFAULT_PORT;
    private int database = 0;
    private String password;
    protected RedisMode mode = RedisMode.STANDALONE;
    protected long timeout = 60*1000L;
    protected boolean running = true;
    protected boolean useSsl;
    /**
     * Maximum number of "idle" connections in the pool. Use a negative value to
     * indicate an unlimited number of idle connections.
     */
    protected int maxIdle = SYS_CORE*4;

    /**
     * Target for the minimum number of idle connections to maintain in the pool. This
     * setting only has an effect if it is positive.
     */
    protected int minIdle = SYS_CORE;

    /**
     * Maximum number of connections that can be allocated by the pool at a given
     * time. Use a negative value for no limit.
     */
    protected int maxActive = SYS_CORE*4;

    /**
     * Maximum amount of time a connection allocation should block before throwing an
     * exception when the pool is exhausted. Use a negative value to block
     * indefinitely.
     */
    protected long maxWait = -1;
    /**
     * Shutdown timeout.
     */
    protected long shutdownTimeout = 10*1000;
    /**
     * Maximum number of redirects to follow when executing commands across the
     * cluster.
     */
    private Integer maxRedirects;
    
    private String master = REDIS_DEFAULT_HOST;
    private int port = REDIS_DEFAULT_PORT;
    private List<RedisNode> nodes = Lists.newArrayList();
    public void setUrl(String url) {
        this.url = url;
    }
    public void setServers(String servers) {
        this.servers = servers;
    }
	public void setMaster(String master) {
		this.master = master;
	}
	/**
       *  描述: 此参数和master配套使用
     * @author ZhangYi
     * @date 2019-12-23 11:12:04
     * @param port
     */
    public void setPort(int port) {
        this.port = port;
    }
    public void setDatabase(int database) {
        this.database = database;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setRunning(boolean running) {
        this.running = running;
    }
    public void setMode(RedisMode mode) {
        this.mode = mode;
    }
    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }
    public void setUseSsl(boolean useSsl) {
        this.useSsl = useSsl;
    }
    public void setMaxIdle(int maxIdle) {
        this.maxIdle = maxIdle;
    }
    public void setMinIdle(int minIdle) {
        this.minIdle = minIdle;
    }
    public void setMaxActive(int maxActive) {
        this.maxActive = maxActive;
    }
    public void setMaxWait(long maxWait) {
        this.maxWait = maxWait;
    }
    public void setShutdownTimeout(long shutdownTimeout) {
        this.shutdownTimeout = shutdownTimeout;
    }
    /**
     * 
       * 	 描述: Redis Cluster Param
     * @author ZhangYi
     * @date 2019-12-23 11:18:27
     * @param maxRedirects
     */
    public void setMaxRedirects(Integer maxRedirects) {
        this.maxRedirects = maxRedirects;
    }
    private void config() {
        try {
            if(!StringUtils.isEmpty(servers)) {
                for (String server : servers.split(",")) {
                    if(StringUtils.isEmpty(server)) {
                        continue;
                    }
                    String[] parts = StringUtils.split(server, ":");
                    master = parts[0];
                    if(parts.length == 2) {
                        port = Integer.valueOf(parts[1]);
                    }
                    if(!StringUtils.isEmpty(master)&&port>0) {
                        nodes.add(new RedisNode(master, port));
                    }
                }
            }
            if (StringUtils.hasText(url)) {
                URI uri = new URI(url);
                useSsl = (url.startsWith("rediss://"));
                if (uri.getUserInfo() != null) {
                    password = uri.getUserInfo();
                    int index = password.indexOf(':');
                    if (index >= 0) {
                        password = password.substring(index + 1);
                    }
                }
                master = uri.getHost();
                servers = uri.getHost();
                port = uri.getPort();
            }
        }catch (Exception ex) {
            throw new IllegalArgumentException("--Redis init Error {url: " + url + ",servers:"+servers+"}", ex);
        }
    }
    
    protected final RedisStandaloneConfiguration getStandaloneConfig() {
        RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
        config();
        config.setHostName(master);
        config.setPort(port);
        if(!StringUtils.isEmpty(password)) {
            config.setPassword(RedisPassword.of(password));
        }
        config.setDatabase(database);
        return config;
    }

    protected final RedisSentinelConfiguration getSentinelConfig() {
        RedisSentinelConfiguration config = new RedisSentinelConfiguration();
        config();
        config.master(master);
        config.setSentinels(nodes);
        if(!StringUtils.isEmpty(password)) {
            config.setPassword(RedisPassword.of(password));
        }
        config.setDatabase(database);
        return config;
    }

    /**
     * Create a {@link RedisClusterConfiguration} if necessary.
     * @return {@literal null} if no cluster settings are set.
     */
    protected final RedisClusterConfiguration getClusterConfiguration() {
        RedisClusterConfiguration config = new RedisClusterConfiguration();
        config();
        if (maxRedirects != null) {
            config.setMaxRedirects(maxRedirects);
        }
        if(!StringUtils.isEmpty(password)) {
            config.setPassword(RedisPassword.of(password));
        }
        return config;
    }
}
