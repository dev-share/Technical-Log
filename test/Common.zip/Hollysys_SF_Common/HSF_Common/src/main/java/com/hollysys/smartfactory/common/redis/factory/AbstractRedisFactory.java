package com.hollysys.smartfactory.common.redis.factory;

import java.time.Duration;
import java.util.concurrent.Executors;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.connection.RedisConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration.LettucePoolingClientConfigurationBuilder;

import com.hollysys.smartfactory.common.cycle.LifeCycle;

import io.lettuce.core.ClientOptions;

/**
 * @decription Redis工厂
 * @author yi.zhang
 * @time 2019/09/18 08:44:52
 * @since 1.0
 * @jdk 1.8
 */
public abstract class AbstractRedisFactory extends AbstractRedisConfigFactory implements LifeCycle {
    private static final Logger logger = LoggerFactory.getLogger(AbstractRedisFactory.class);
    protected LettuceConnectionFactory factory = null;
	private boolean shareConnection = true;
	private ClientOptions.Builder options = ClientOptions.builder();
    public ClientOptions.Builder getOptions() {
        return options;
    }
    public void setOptions(ClientOptions.Builder options) {
        this.options = options;
    }
    public void setShareConnection(boolean shareConnection) {
        this.shareConnection = shareConnection;
    }
    public abstract void init();
    /**
	 * @decription 初始化配置
	 * @author yi.zhang
	 * @time 2017年6月2日 下午2:15:57
	 */
    protected void build() {
		try {
		    GenericObjectPoolConfig<Object> poolConfig = new GenericObjectPoolConfig<>();
            poolConfig.setMaxIdle(maxIdle);
            poolConfig.setMinIdle(minIdle);
            poolConfig.setMaxTotal(maxActive);
            LettucePoolingClientConfigurationBuilder builder =  LettucePoolingClientConfiguration.builder();
            builder.commandTimeout(Duration.ofMillis(timeout));
            builder.shutdownTimeout(Duration.ofMillis(shutdownTimeout));
            builder.poolConfig(poolConfig);
            options.autoReconnect(true);
            builder.clientOptions(options.build());
            if(useSsl) {
                builder.useSsl().and();
            }
            LettuceClientConfiguration lettuceClientConfiguration = builder.build();
            RedisConfiguration config = null;
            if(mode.equals(RedisMode.CLUSTER)) {
                config = getClusterConfiguration();
            }else if(mode.equals(RedisMode.SENTINEL)) {
                config = getClusterConfiguration();
            }else {
                config = getStandaloneConfig();
            }
            factory = new LettuceConnectionFactory(config,lettuceClientConfiguration);
            factory.setShareNativeConnection(shareConnection);
            factory.afterPropertiesSet();
            factory.initConnection();
		} catch (Exception e) {
			logger.error("-----Redis Config init Error-----", e);
		}
	}
	@Override
	public void start() {
		boolean delay = delay();
		if(!delay) {
			init();
		}
        Executors.newSingleThreadExecutor().execute(() -> {
            while (running) {
                try {
                    if(factory==null) {
                    	reconnect();
                    }
//                  if(factory!=null&&!factory.getValidateConnection()) {
//                      factory.initConnection();
//                  }
                    Thread.sleep(1000l);
                } catch (InterruptedException e) {
                    logger.error("--Kafka Interrupted...",e);
                    Thread.currentThread().interrupt();
                }
            }
        });
    }
    @Override
	public void reconnect() {
		close();
		init();
	}
	/**
	 * 关闭服务
	 */
    @Override
	public void close() {
		if (factory != null) {
		    factory.destroy();
		}
	}
}
