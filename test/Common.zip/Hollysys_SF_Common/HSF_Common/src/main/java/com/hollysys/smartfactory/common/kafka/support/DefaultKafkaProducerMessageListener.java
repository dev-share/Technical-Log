 package com.hollysys.smartfactory.common.kafka.support;

import com.hollysys.smartfactory.common.kafka.KafkaProducerMessageListener;

/**
  * @description Kafka默认生产者消息监听处理
  * @author ZhangYi
  * @date 2019/09/18 14:25:31
  * @version 1.0.0 
  * @Jdk 1.8
  */
 public class DefaultKafkaProducerMessageListener extends KafkaProducerMessageListener{
     @Override
     public void init() {
         logger.info("--Kafka Producer init default...");
     }
 }
