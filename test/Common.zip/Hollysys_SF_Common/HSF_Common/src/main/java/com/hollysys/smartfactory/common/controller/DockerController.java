package com.hollysys.smartfactory.common.controller;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Maps;
import com.hollysys.smartfactory.common.config.SystemGlobalConfig;

/**
 * @project SF_Common_Service
 * @description Docker健康检查
 * @author ZhangYi
 * @date 2019/09/23 16:47:57
 * @version 1.0.0 
 * @Jdk 1.8
 */
@RestController
@RequestMapping(value = "/docker")
public class DockerController extends BaseController{
    @GetMapping(value = "/health")
	public ResponseEntity<Object> health(HttpServletRequest request,HttpServletResponse response) throws Exception {
    	String host = getHostAddr(request);
    	Map<String,Object> result = Maps.newHashMap();
    	result.put("clientIP", host);
    	result.put("serverIP", SystemGlobalConfig.SYSTEM_HOST);
    	result.put("status", HttpStatus.OK);
    	result.put("timestamp", Clock.systemUTC().millis());
    	result.put("datetime", LocalDateTime.now());
    	Map<String, String> zones = ZoneId.SHORT_IDS;
    	String zoneId = ZoneId.systemDefault().getId();
    	result.put("timezone", zones.containsKey(zoneId)?zones.get(zoneId):ZoneId.systemDefault());
    	return new ResponseEntity<>(result,HttpStatus.OK);
    }
   
}
