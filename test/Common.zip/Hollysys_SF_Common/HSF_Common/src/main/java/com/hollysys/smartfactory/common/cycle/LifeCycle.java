package com.hollysys.smartfactory.common.cycle;
/**
     *   项目: sf-common
     *   描述: 服务生命周期
  * @author ZhangYi
  * @date 2019-10-25 12:30:07
     *   版本: v1.0
  * JDK: 1.8
 */
public interface LifeCycle extends AutoCloseable{
	/**
	   *  描述: 启动服务
	 * @author ZhangYi
	 * @date 2019-10-25 12:30:34
	 */
	public void start();
	/**
	   *  描述: 关闭(销毁)服务
	 * @author ZhangYi
	 * @date 2019-10-25 12:30:34
	 */
    public void reconnect();
	/**
	   *  描述: 是否延迟加载
	 * @author ZhangYi
	 * @date 2019-10-25 12:30:34
	 */
    public boolean delay();
}
