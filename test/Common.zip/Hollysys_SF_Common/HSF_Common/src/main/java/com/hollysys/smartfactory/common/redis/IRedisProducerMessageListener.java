package com.hollysys.smartfactory.common.redis;

import org.springframework.data.redis.core.ReactiveRedisTemplate;

/**
 * @description Redis生产者消息监听处理
 * @author ZhangYi
 * @date 2019/09/18 08:44:52
 * @version 1.0.0
 * @Jdk 1.8
 */
public interface IRedisProducerMessageListener {
    public void setTemplate(ReactiveRedisTemplate<String, String> template);
    public void setDefaultTopic(String defaultTopic);
    public boolean send(Object data);
    public boolean send(String topic, Object data);
}
