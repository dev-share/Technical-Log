package com.hollysys.smartfactory.common.kafka;

/**
 * @description Kafka消费者消息监听处理
 * @author ZhangYi
 * @date 2019/09/18 08:44:52
 * @version 1.0.0
 * @Jdk 1.8
 */
public interface KafkaConsumerMessageListener {
    /**
     * @description 消费消息
     * @author ZhangYi
     * @date 2019/09/18 14:30:18
     * @param topic 消息主题
     * @param data 消息数据
     * @return
     */
    public boolean handle(String topic, String data);
}
