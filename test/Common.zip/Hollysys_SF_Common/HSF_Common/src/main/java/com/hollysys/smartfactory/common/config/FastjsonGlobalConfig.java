package com.hollysys.smartfactory.common.config;

import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.ResourceHttpMessageConverter;
import org.springframework.http.converter.ResourceRegionHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.http.converter.xml.SourceHttpMessageConverter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;

/**
 * 
 * @project SF_Common_Service
 * @description 序列号请求响应
 * 
 * @author ZhangYi
 * @date 2019-06-18 15:41:57
 * @version v1.0
 * @Jdk 1.8
 */
@Configuration
public class FastjsonGlobalConfig implements WebMvcConfigurer {
    @SuppressWarnings("rawtypes")
	@Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        // 创建配置类
        FastJsonConfig config = new FastJsonConfig();
        SerializerFeature[] serializerFeatures =
            new SerializerFeature[] {SerializerFeature.BrowserSecure, SerializerFeature.BrowserCompatible,
                SerializerFeature.DisableCircularReferenceDetect, SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteNullListAsEmpty, SerializerFeature.WriteNullStringAsEmpty};
        config.setSerializerFeatures(serializerFeatures);
        //spring-boot:默认转换器如下
        //[0]:ByteArrayHttpMessageConverter
        //[1]:StringHttpMessageConverter
        //[2]:StringHttpMessageConverter
        //[3]:ResourceHttpMessageConverter
        //[4]:ResourceRegionHttpMessageConverter
        //[5]:SourceHttpMessageConverter
        //[6]:AllEncompassingFormHttpMessageConverter
        //[7]:MappingJackson2HttpMessageConverter
        //[8]:MappingJackson2HttpMessageConverter
        //[9]:Jaxb2RootElementHttpMessageConverter
        // 将Fastjson转换器至于Jackson之前
        FastJsonHttpMessageConverter converter = new FastJsonHttpMessageConverter();
        converter.setFastJsonConfig(config);
        if(converters!=null&&converters.size()<7) {
        	converters.add(new ByteArrayHttpMessageConverter());
        	converters.add(new StringHttpMessageConverter());
        	converters.add(new StringHttpMessageConverter());
        	converters.add(new ResourceHttpMessageConverter());
        	converters.add(new ResourceRegionHttpMessageConverter());
        	converters.add(new SourceHttpMessageConverter());
        	converters.add(new AllEncompassingFormHttpMessageConverter());
        	converters.add(new MappingJackson2HttpMessageConverter());
        	converters.add(new MappingJackson2HttpMessageConverter());
        	converters.add(new Jaxb2RootElementHttpMessageConverter());
        }
        converters.add(7,converter);
    }
}
