package com.hollysys.smartfactory.common.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;

import com.github.pagehelper.PageInfo;
import com.hollysys.smartfactory.common.bean.AjaxResult;
import com.hollysys.smartfactory.common.bean.AjaxResult.PAjaxResult;
import com.hollysys.smartfactory.common.bean.ReturnInfo;
import com.hollysys.smartfactory.common.util.FTPUtils;
import com.hollysys.smartfactory.common.util.HttpUtils;

/**
 * @project SF_Common_Service
 * @description 组件控制器封装
 * @author ZhangYi
 * @date 2019/09/23 16:47:57
 * @version 1.0.0 
 * @Jdk 1.8
 */
public class BaseController {
	/**
     * 请求头未知信息
     */
	public static final String HEADER_UNKNOWN = "unknown";
    /**
     * @description ajax请求响应封装 作者: ZhangYi 时间: 2019年3月15日 上午9:02:48 参数: (参数列表)
     * 
     * @param message 响应消息
     * @return
     */
    public AjaxResult error(String message) {
        return new AjaxResult(AjaxResult.AJAX_STATUS_ERROR).setMessage(message);
    }

    /**
     * @description ajax请求响应封装 作者: ZhangYi 时间: 2019年3月15日 上午9:02:48 参数: (参数列表)
     * 
     * @param message 响应消息
     * @param status 状态码
     * @return
     */
    public AjaxResult error(String message, int status) {
        return new AjaxResult(AjaxResult.AJAX_STATUS_ERROR).setMessage(message).setStatuscode(status);
    }

    /**
     * @description ajax请求响应封装 作者: ZhangYi 时间: 2019年3月15日 上午8:59:50 参数: (参数列表)
     * 
     * @param message 响应消息
     * @return
     */
    public AjaxResult success(String message) {
        return new AjaxResult(AjaxResult.AJAX_STATUS_SUCCESS).setMessage(message);
    }

    /**
     * @description ajax请求响应封装 作者: ZhangYi 时间: 2019年3月15日 上午8:59:50 参数: (参数列表)
     * 
     * @param message 响应消息
     * @param results 响应对象(List<T>,Map<Object,T>,T对象或基本类型等)
     * @return
     */
    public AjaxResult success(String message, Object results) {
        return new AjaxResult(AjaxResult.AJAX_STATUS_SUCCESS).setMessage(message).setResults(results);
    }

    /**
     * @description ajax请求分页响应封装 作者: ZhangYi 时间: 2019年3月15日 上午8:58:25 参数: (参数列表)
     * 
     * @param message 响应消息
     * @param pageInfo 分页对象
     * @return
     */
    public <T> AjaxResult success(String message, PageInfo<T> pageInfo) {
        return new PAjaxResult(AjaxResult.AJAX_STATUS_SUCCESS).setTotal(pageInfo.getTotal())
            .setPageNum(pageInfo.getPageNum()).setPageSize(pageInfo.getPageSize()).setMessage(message)
            .setResults(pageInfo.getList());
    }

    /**
     * 
     * @description 文件下载
     * 
     * @author ZhangYi
     * @date 2019-03-29 13:38:18
     * @param basePath 文件路径
     * @param fileName 文件名称
     * @return
     * @throws URISyntaxException
     * @throws IOException
     */
    public Object download(String basePath, String fileName, String attachmentName)
        throws URISyntaxException, IOException {
        InputStream in = null;
        if (!StringUtils.isEmpty(fileName)) {
            String path = basePath
                + (!StringUtils.isEmpty(basePath) && (basePath.endsWith("/") || basePath.endsWith("\\")) ? "/" : "")
                + fileName;
            if (path.startsWith(FTPUtils.PROTOCOL_FTP)) {
                URI url = new URI(path);
                in = FTPUtils.download(url.getPath(), url.getHost());
            } else if (path.startsWith(HttpUtils.PROTOCOL_HTTP) || path.startsWith(HttpUtils.PROTOCOL_HTTPS)) {
                URI url = new URI(path);
                in = !HttpUtils.checkConnection(url.toString(), null) ? null
                    : HttpUtils.download(url.toString(), HttpUtils.METHOD_GET, null, null);
            } else {
                URI url = Paths.get(path).toUri();
                UrlResource resource = new UrlResource(url);
                boolean valid = resource != null && (resource.exists() || resource.isReadable());
                if (valid) {
                    fileName = resource.getFilename();
                    fileName = !StringUtils.isEmpty(fileName) && fileName.matches("(\\s)")
                        ? fileName.replaceAll("(\\s)", "") : fileName;
                    in = resource.getInputStream();
                }
            }
        }
        if (in != null) {
            fileName = StringUtils.isEmpty(attachmentName) ? fileName : attachmentName;
            BodyBuilder bulder = ResponseEntity.ok();
            bulder.cacheControl(CacheControl.empty().mustRevalidate());
            bulder.header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment;fileName=" + URLEncoder.encode(fileName, StandardCharsets.UTF_8.name()));
            bulder.header(HttpHeaders.PRAGMA, CacheControl.noCache().getHeaderValue());
            bulder.header(HttpHeaders.EXPIRES, "0");
            // bulder.contentLength(resource.contentLength());
            bulder.contentType(MediaType.valueOf(MediaType.APPLICATION_OCTET_STREAM_VALUE));
            ResponseEntity<InputStreamResource> resp = bulder.body(new InputStreamResource(in));
            return resp;
        } else {
            return error(ReturnInfo.DOWNLOAD_ERROR_MSG);
        }
    }
    /**
     * 描述:获取客户端IP地址
     * 
     * @author ZhangYi 时间:2016年2月3日 上午10:43:55 参数：(参数列表)
     * 
     * @param request
     * @return
     */
    public String getHostAddr(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (!StringUtils.isEmpty(ip) && ip.indexOf(",") != -1) {
            ip = ip.substring(ip.lastIndexOf(",") + 1, ip.length()).trim();
        }
        if (StringUtils.isEmpty(ip) || ip.equals("0:0:0:0:0:0:0:1")) {
            ip = request.getServerName();
        }
        return StringUtils.isEmpty(ip) || ip.equals("localhost") ? "127.0.0.1" : ip;
    }
}
