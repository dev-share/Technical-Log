 package com.hollysys.smartfactory.common.redis;

import org.springframework.data.redis.core.ReactiveRedisTemplate;

/**
 * @project HSF_Common
 * @description 
 * @author ZhangYi
 * @date 2019/09/27 15:21:54
 * @version 1.0.0 
 * @Jdk 1.8 
 */
public interface IRedisTemplateListener {
    public void setRedisTemplate(ReactiveRedisTemplate<String,Object> tempalte);
}
