 package com.hollysys.smartfactory.common.kafka.factory;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.CommonClientConfigs;

import com.google.common.collect.Maps;
import com.hollysys.smartfactory.common.cycle.LifeCycle;

/**
 * @project SF_TargetCalculate_Service
 * @description Kafka配置工厂
 * @author ZhangYi
 * @date 2019/09/17 19:25:36
 * @version 1.0.0 
 * @Jdk 1.8 
 */
public abstract class AbstractKafkaFactory implements LifeCycle{
    /**
     * Kafka默认主题
     */
    public static final String KAFKA_DEFAULT_TOPIC = "KAFKA_DEFAULT_TOPIC";
    private String servers;
    private int timeout;
    protected String[] topics;
    protected boolean running = true;
    private Map<String, Object> config;
    
    public void setServers(String servers) {
        this.servers = servers;
    }
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }
    public void setTopics(String topics) {
        this.topics = StringUtils.isBlank(topics)?new String[]{KAFKA_DEFAULT_TOPIC}:topics.split(",");
    }
    public void setConfig(Map<String, Object> config) {
        this.config = config;
    }
    public void setRunning(boolean running) {
        this.running = running;
    }
    protected Map<String, Object> deafultConfig(){
    	Map<String, Object> dconfig = Maps.newConcurrentMap();
        if(config!=null) {
            dconfig.putAll(config);
        }
        config = dconfig;
        if(StringUtils.isNotBlank(servers)) {
            config.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, servers);
        }
        if(!config.containsKey(CommonClientConfigs.RECONNECT_BACKOFF_MS_CONFIG)) {
            // 重试连接时长
            config.put(CommonClientConfigs.RECONNECT_BACKOFF_MS_CONFIG, 1000L);
        }
        if(!config.containsKey(CommonClientConfigs.RECONNECT_BACKOFF_MAX_MS_CONFIG)) {
            // 重试连接最大时长
            config.put(CommonClientConfigs.RECONNECT_BACKOFF_MAX_MS_CONFIG, 10*1000L);
        }
        if(!config.containsKey(CommonClientConfigs.CONNECTIONS_MAX_IDLE_MS_CONFIG)) {
            // 失败重试次数
            config.put(CommonClientConfigs.CONNECTIONS_MAX_IDLE_MS_CONFIG, 10*60*1000L);
        }
        if(timeout>-1) {
            // 请求超时时长
            config.put(CommonClientConfigs.REQUEST_TIMEOUT_MS_CONFIG, timeout);
        }
        return config;
    }
}
