package com.hollysys.smartfactory.common.redis.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.RedisSerializationContext.RedisSerializationContextBuilder;

import com.alibaba.fastjson.support.spring.FastJsonRedisSerializer;
import com.hollysys.smartfactory.common.redis.IRedisTemplateListener;

/**
 * @decription Redis工厂(数据操作)
 * @author yi.zhang
 * @time 2019/09/18 08:44:52
 * @since 1.0
 * @jdk 1.8
 */
public class RedisDataFactory extends AbstractRedisFactory {
    private static final Logger logger = LoggerFactory.getLogger(RedisDataFactory.class);
	private IRedisTemplateListener listener = null;
    public void setListener(IRedisTemplateListener listener) {
        this.listener = listener;
    }
    /**
	 * @decription 初始化配置
	 * @author yi.zhang
	 * @time 2017年6月2日 下午2:15:57
	 */
	public void init() {
		try {
		    super.build();
            FastJsonRedisSerializer<String> fastjson = new FastJsonRedisSerializer<>(String.class);
            RedisSerializationContextBuilder<String, Object> serialize = RedisSerializationContext.<String,Object>newSerializationContext();
            serialize.hashKey(fastjson);
            serialize.hashValue(fastjson);
            serialize.key(fastjson);
            serialize.value(new FastJsonRedisSerializer<>(Object.class));
            serialize.string(fastjson);
            ReactiveRedisTemplate<String,Object> template = new ReactiveRedisTemplate<>(factory, serialize.build());
            listener.setRedisTemplate(template);
		} catch (Exception e) {
			logger.error("-----Redis Config init Error-----", e);
		}
	}
	@Override
	public boolean delay() {
		 return false;
	}
}
