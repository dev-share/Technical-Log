package com.hollysys.smartfactory.common.model.req;

import java.io.Serializable;

import javax.validation.constraints.AssertTrue;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiParam;
import lombok.Data;

/**
 * @project SF_Common_Service
 * @description 关键字搜索请求
 * @author ZhangYi
 * @date 2019/09/23 16:48:43
 * @version 1.0.0 
 * @Jdk 1.8
 */
@ApiModel
@Data
public class KeywordReq implements Serializable {
    private static final long serialVersionUID = 593337977097059032L;
    @ApiParam(value = "关键字")
    protected String keyword;

    @AssertTrue
    private boolean isTransform() {
        if (StringUtils.isNotBlank(keyword)) {
            keyword = StringEscapeUtils.escapeXSI(keyword);
//            keyword = keyword.replaceAll("$", "/$").replaceAll("#", "/#");
        }
        return true;
    }
}
