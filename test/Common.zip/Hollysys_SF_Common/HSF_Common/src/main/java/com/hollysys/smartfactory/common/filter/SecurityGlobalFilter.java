package com.hollysys.smartfactory.common.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.GenericFilter;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import com.alibaba.fastjson.JSON;
import com.hollysys.smartfactory.common.bean.AjaxResult;

/**
 * @project SF_Common_Service
 * @description 系统过滤器
 * 
 * @author ZhangYi
 * @date 2019-05-20 15:21:55
 * @version v1.0
 * @Jdk 1.8
 */
@Configuration
@Order(Ordered.HIGHEST_PRECEDENCE)
@WebFilter("/*")
public class SecurityGlobalFilter extends GenericFilter {
    private static final long serialVersionUID = 4219259460924503872L;
    private static Logger logger = LoggerFactory.getLogger(SecurityGlobalFilter.class);
    /**
     * 请求头未知信息
     */
    private static String HEADER_UNKNOWN = "unknown";
    /**
     * html注入
     */
    private static String[] ILLEGAL_HTML =
        {"<", ">", /*"%", "&", */ "-->", /* "\"","'",";","(",")","+", */"</script>", "</iframe>", "\\ssrc="};
    /**
     * SQL的注入关键字符
     */
    private static String[] ILLEGAL_SQL = {"select\\s", "from\\s", "insert\\s", "delete\\s", "update\\s", "drop\\s",
        "truncate\\s", "exec\\s", "count\\(", "declare\\s", "asc\\(", "mid\\(", "char\\(", "net user", "xp_cmdshell",
        "/add\\s", "exec master.dbo.xp_cmdshell", "net localgroup administrators"};

    @Override
    public void init(FilterConfig config) throws ServletException {
        logger.info("-----------------系统Filter参数初始化-----------------");
    }

    /**
     * 
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest)request;
        HttpServletResponse resp = (HttpServletResponse)response;
        Cookie[] cookies = req.getCookies();
        String url = req.getRequestURI();
        Map<String, String[]> params = req.getParameterMap();
        if (params != null && !params.isEmpty()) {// 参数值安全拦截
            for (Map.Entry<String, String[]> entry : params.entrySet()) {
                String[] values = params.get(entry.getKey());
                if (values != null && values.length > 0) {
                    for (String value : values) {
                        if (sqlRegex(value) || htmlRegex(value)) {
                            logger.error("--非法入侵:{IP:{},入侵代码:{}}", getHostAddr(req), value);
                            filterError(resp, "Illegal intrusion:" + value);
                            return;
                        }
                    }
                }
            }
        }
        if (url.startsWith("/")) {
            chain.doFilter(request, response);
        } else {
            String token = (String)((HttpServletRequest)request).getSession().getAttribute("token");
            if (StringUtils.isEmpty(token) && cookies != null) {
                for (Cookie cookie : cookies) {
                    if ("token".equals(cookie.getName())) {
                        token = cookie.getValue();
                    }
                }
            }
            if (!StringUtils.isEmpty(token)) {
                // 更改cookie的生命周期为关闭浏览器就销毁
                if (cookies != null) {
                    for (Cookie cookie : cookies) {
                        cookie.setMaxAge(-1);
                        cookie.setPath("/");
                        // 此处可以补充更新token的方法，比如加上token的时间有效性检验
                        ((HttpServletResponse)response).setHeader("P3P: CP",
                            "CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA div COM NAV OTC NOI DSP COR");
                        ((HttpServletResponse)response).addCookie(cookie);
                    }
                }
                chain.doFilter(request, response);
            } else {
                filterError(resp, "Unauthorized");
            }
        }
    }

    @Override
    public void destroy() {
        logger.info("-----------------系统Filter销毁-----------------");
    }

    /**
     * @description 鉴权错误
     * 
     * @author ZhangYi
     * @date 2019-05-10 11:31:56
     * @param resp Response
     * @param message 消息
     * @throws IOException
     */
    public void filterError(HttpServletResponse resp, String message) throws IOException {
        AjaxResult result = new AjaxResult(403);
        result.setMessage(message);
        PrintWriter out = resp.getWriter();
        out.write(JSON.toJSONString(result));
    }

    /**
     * 描述:SQL注入正则
     * 
     * @author ZhangYi 时间:2016年2月3日 上午10:30:25 参数：(参数列表)
     * @param value
     * @return
     */
    protected boolean sqlRegex(String value) {
        if (StringUtils.isEmpty(value)) {
            return false;
        }
        value = StringEscapeUtils.escapeXSI(value);
        // 构造正则表达式
        String regex = ".*(";
        for (int i = 0; i < ILLEGAL_SQL.length - 1; i++) {
            regex += ILLEGAL_SQL[i] + "|";
        }
        regex += ILLEGAL_SQL[ILLEGAL_SQL.length - 1] + ").*";
        return Pattern.compile(regex).matcher(value.toLowerCase()).matches();
    }

    /**
     * 描述:html注入正则
     * 
     * @author ZhangYi 时间:2016年2月3日 上午10:29:46 参数：(参数列表)
     * @param value
     * @return
     */
    protected boolean htmlRegex(String value) {
        if (StringUtils.isEmpty(value)) {
            return false;
        }
        value = StringEscapeUtils.escapeHtml4(value);
        // 构造html的注入(比如:</script>"'></iframe><IFRAME
        // SRC="http://www.tomqsjaz.com/ordew.html">)
        // 构造正则表达式
        String regex = ".*(";
        for (int i = 0; i < ILLEGAL_HTML.length - 1; i++) {
            regex += ILLEGAL_HTML[i] + "|";
        }
        regex += ILLEGAL_HTML[ILLEGAL_HTML.length - 1] + ").*";
        return Pattern.compile(regex).matcher(value.toLowerCase()).matches();
    }

    /**
     * 描述:获取客户端IP地址
     * 
     * @author ZhangYi 时间:2016年2月3日 上午10:43:55 参数：(参数列表)
     * 
     * @param request
     * @return
     */
    public String getHostAddr(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (StringUtils.isEmpty(ip) || HEADER_UNKNOWN.equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (!StringUtils.isEmpty(ip) && ip.indexOf(",") != -1) {
            ip = ip.substring(ip.lastIndexOf(",") + 1, ip.length()).trim();
        }
        if (StringUtils.isEmpty(ip) || ip.equals("0:0:0:0:0:0:0:1")) {
            ip = request.getServerName();
        }
        return StringUtils.isEmpty(ip) || ip.equals("localhost") ? "127.0.0.1" : ip;
    }
}
