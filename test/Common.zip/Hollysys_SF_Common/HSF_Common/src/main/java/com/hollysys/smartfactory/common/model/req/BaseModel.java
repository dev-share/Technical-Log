package com.hollysys.smartfactory.common.model.req;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
/**
 * @project SF_Common_Service
 * @description 基本请求体
 * @author ZhangYi
 * @date 2019/09/23 17:10:44
 * @version 1.0.0 
 * @Jdk 1.8
 */
@Data
@ApiModel(description = "指标控件")
public class BaseModel  implements Serializable{
    /**
     *
     */
    private static final long serialVersionUID = 3034010379467720652L;
    @ApiModelProperty(value = "主键id")
    private String pkid;
    
}
