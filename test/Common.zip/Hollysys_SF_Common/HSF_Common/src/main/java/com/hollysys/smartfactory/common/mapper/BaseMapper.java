package com.hollysys.smartfactory.common.mapper;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * @project SF_Common_Service
 * @description 数据访问操作接口
 * @author ZhangYi
 * @date 2019/09/23 17:05:24
 * @version 1.0.0 
 * @Jdk 1.8
 */
@MapperScan(basePackages= {"com.hollysys.smartfactory.*.mapper","com.hollysys.smartfactory.*.dao","com.hollysys.smartfactory.*.dao.mapper"})
public interface BaseMapper<T> extends Mapper<T>, MySqlMapper<T> {
	
}
