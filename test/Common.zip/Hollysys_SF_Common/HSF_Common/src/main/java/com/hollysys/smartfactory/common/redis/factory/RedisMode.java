 package com.hollysys.smartfactory.common.redis.factory;

import org.apache.commons.lang.StringUtils;

/**
 * @project HSF_Common
 * @description Redis模式
 * @author ZhangYi
 * @date 2019/09/29 09:02:25
 * @version 1.0.0 
 * @Jdk 1.8 
 */
public enum RedisMode {
    /**
     * 单机模式
     */
    STANDALONE("Standalone"),
    /**
     * 哨兵模式
     */
    SENTINEL("Sentinel"),
    /**
     * 集群模式
     */
    CLUSTER("Cluster");
    
    private String mode;
    /**
     * @param mode
     */
    private RedisMode(String mode) {
        this.mode = mode;
    }
    public String getMode() {
        return mode;
    }
    public RedisMode modeOf(String mode) {
        if (StringUtils.isBlank(mode)) {
            return null;
        }
        for (RedisMode obj : RedisMode.values()) {
            if (obj != null && obj.getMode().equalsIgnoreCase(mode)) {
                return obj;
            }
        }
        return null;
    }
}
