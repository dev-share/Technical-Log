package com.hollysys.smartfactory.common.model.resp;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @project SF_Common_Service
 * @description 基础响应视图
 * @author ZhangYi
 * @date 2019/09/23 17:15:15
 * @version 1.0.0 
 * @Jdk 1.8
 */
@ApiModel(description = "基础响应视图")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
public class BaseView implements Serializable {
    private static final long serialVersionUID = -4360092984910855572L;
    private String pkid;
    
}
