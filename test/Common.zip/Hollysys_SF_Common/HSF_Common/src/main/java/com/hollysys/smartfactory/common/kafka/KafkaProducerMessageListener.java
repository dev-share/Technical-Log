package com.hollysys.smartfactory.common.kafka;

import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * @description Kafka生产者消息监听处理
 * @author ZhangYi
 * @date 2019/09/18 08:44:52
 * @version 1.0.0
 * @Jdk 1.8
 */
public abstract class KafkaProducerMessageListener {
    protected static Logger logger = LoggerFactory.getLogger(KafkaProducerMessageListener.class);
    private KafkaTemplate<String, String> template;

    public abstract void init();

    public void setTemplate(KafkaTemplate<String, String> template) {
        this.template = template;
        init();
    }

    public boolean send(Object data) {
        return send(template.getDefaultTopic(), data);
    }

    public boolean send(String topic, Object data) {
        boolean flag = true;
        try {
            if (StringUtils.isBlank(topic)) {
                topic = template.getDefaultTopic();
            }
            String key = "DEFAULT_KAFKA_KEY";
            String value = null;
            if (data != null) {
                if (data instanceof String) {
                    value = data.toString();
                } else if (data instanceof JSONObject) {
                    value = ((JSONObject)data).toJSONString();
                } else {
                    value = JSON.toJSONString(data);
                }
            }
            template.send(new ProducerRecord<String, String>(topic, key, value));
        } catch (Exception e) {
            logger.error("---kafka[" + topic + "] send error !", e);
            flag = false;
        }
        return flag;
    }
}
