 package com.hollysys.smartfactory.common.kafka.support;

import com.hollysys.smartfactory.common.kafka.KafkaConsumerMessageListener;

/**
  * @description Kafka默认消费者消息监听处理
  * @author ZhangYi
  * @date 2019/09/18 14:25:31
  * @version 1.0.0 
  * @Jdk 1.8
  */
 public class DefaultKafkaConsumerMessageListener implements KafkaConsumerMessageListener{
     /**
      * Kafka是否消费消息
      */
     public static final boolean DEFAULT_ACK_ENABLED = false;
     @Override
     public boolean handle(String topic, String data) {
          return DEFAULT_ACK_ENABLED;
     }
 }
