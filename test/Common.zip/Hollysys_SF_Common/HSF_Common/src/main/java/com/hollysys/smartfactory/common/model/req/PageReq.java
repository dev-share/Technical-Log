package com.hollysys.smartfactory.common.model.req;

import java.io.Serializable;

import javax.validation.constraints.AssertTrue;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiParam;
import lombok.Data;

/**
 * @project SF_Common_Service
 * @description 分页搜索请求
 * @author ZhangYi
 * @date 2019/09/23 16:48:43
 * @version 1.0.0 
 * @Jdk 1.8
 */
@ApiModel
@Data
public class PageReq implements Serializable {
    private static final long serialVersionUID = 6244362557029753676L;
    /**
     * 分页当前默认页:1
     */
    public static final int PAGE_DEFAULT_PAGENO = 1;
    /**
     * 分页每页默认数量:2^31-1
     */
    public static final int PAGE_DEFAULT_PAGESIZE = Integer.MAX_VALUE;
    @ApiParam(name = "page", value = "当前页", defaultValue = "1")
    private Integer page;

    @ApiParam(value = "每页数量", defaultValue = "10")
    private Integer pageSize;

    @ApiParam(value = "游标偏移量", hidden = true)
    public Integer getOffset() {
        int limit = pageSize != null ? pageSize : PAGE_DEFAULT_PAGESIZE;
        int pageNum = page != null && page > 0 ? page : PAGE_DEFAULT_PAGENO;
        int offset = (pageNum - 1) * limit + 1;
        return offset;
    }

    @AssertTrue
    private boolean isInit() {
        if (page == null || page < 1) {
            page = PAGE_DEFAULT_PAGENO;
        }
        if (pageSize == null || pageSize < 1) {
            pageSize = PAGE_DEFAULT_PAGESIZE;
        }
        return true;
    }
}
