package com.hollysys.smartfactory.common.model.entity;

import lombok.Data;

/**
 * @project SF_Common_Service
 * @description 基础实体类
 * @author ZhangYi
 * @date 2019/09/23 17:13:18
 * @version 1.0.0 
 * @Jdk 1.8
 */
@Data
public class BaseEntity {
    private String pkid;
    
}
