package com.hollysys.smartfactory.common.kafka.factory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.RangeAssignor;
import org.apache.kafka.clients.consumer.RoundRobinAssignor;
import org.apache.kafka.clients.consumer.StickyAssignor;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.AcknowledgingMessageListener;
import org.springframework.kafka.listener.BatchAcknowledgingMessageListener;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.ContainerProperties.AckMode;
import org.springframework.kafka.support.Acknowledgment;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.hollysys.smartfactory.common.config.SystemGlobalConfig;
import com.hollysys.smartfactory.common.kafka.KafkaConsumerMessageListener;

/**
 * @decription Kafka消费者工厂
 * @author yi.zhang
 * @time 2019/09/18 08:44:52
 * @since 1.0
 * @jdk 1.8
 */
public class KafkaConsumerFactory extends AbstractKafkaFactory {
    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerFactory.class);
    /**
     * Kafka默认消费分组
     */
    public static final String KAFKA_DEFAULT_GROUPID = "KAFKA_DEFAULT_GROUPID";
	private KafkaConsumerMessageListener listener = null;
	private ConcurrentMessageListenerContainer<String, String> service = null;
	private String groupId;
	private boolean isBatch;
	private boolean isPattern;
	private boolean autoCommit;
    private int commitInterval;
    private int concurrency;
    private String strategy;
    private int maxRecords = 500;

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public void setBatch(boolean isBatch) {
	    this.isBatch = isBatch;
	}
    public void setPattern(boolean isPattern) {
        this.isPattern = isPattern;
    }
	public void setMaxRecords(int maxRecords) {
		this.maxRecords = maxRecords;
	}
	public void setAutoCommit(boolean autoCommit) {
        this.autoCommit = autoCommit;
    }
    public void setCommitInterval(int commitInterval) {
        this.commitInterval = commitInterval;
    }
    public void setConcurrency(int concurrency) {
        this.concurrency = concurrency;
    }
    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }
    public void setListener(KafkaConsumerMessageListener listener) {
        this.listener = listener;
    }
    /**
	 * @decription 初始化配置
	 * @author yi.zhang
	 * @time 2017年6月2日 下午2:15:57
	 */
	private void init() {
		try {
		    Map<String, Object> config = deafultConfig();
		    if(StringUtils.isBlank(groupId)) {
		        groupId = KAFKA_DEFAULT_GROUPID;
		    }
		    if(StringUtils.isNotBlank(groupId)) {
		        // 消费者的组
		        config.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		    }
		    config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxRecords);
		    config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
		    config.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, commitInterval);
		    config.put(ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG, Collections.singletonList(ComsumerStrategy.strategy(strategy)));
		    config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		    config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
			DefaultKafkaConsumerFactory<String, String> factory = new DefaultKafkaConsumerFactory<>(config);
			topics = (topics==null||topics.length<1)?new String[]{KAFKA_DEFAULT_TOPIC}:topics;
			ContainerProperties container = isPattern?new ContainerProperties(Pattern.compile(topics[0])):new ContainerProperties(topics);
			if(!autoCommit) {
			    container.setAckMode(AckMode.MANUAL_IMMEDIATE);
            }
			if(isBatch) {
			    container.setMessageListener(new BatchAcknowledgingMessageListener<String, String>() {
                    @Override
                    public void onMessage(List<ConsumerRecord<String, String>> list, Acknowledgment ack) {
                        Map<String,List<Object>> map = Maps.newConcurrentMap();
                        try {
                            if(list!=null&&!list.isEmpty()) {
                                for (ConsumerRecord<String, String> record : list) {
                                    String topic = record.topic();
                                    String value = record.value();
                                    if(!map.containsKey(topic)) {
                                        map.put(topic, new ArrayList<Object>());
                                    }
                                    Object data = value;
                                    if(JSON.isValid(value)) {
                                       if(JSON.isValidArray(value)) {
                                           data = JSON.parseArray(value,JSONObject.class);
                                       }else {
                                           data = JSON.parseObject(value, JSONObject.class);
                                       }
                                    }
                                    if(data instanceof List) {
                                        map.get(topic).addAll((List<?>)data);
                                    }else {
                                        map.get(topic).add(data);
                                    }
                                }
                            }
                            boolean success = false;
                            if(!map.isEmpty()) {
                                for (Map.Entry<String,List<Object>> obj : map.entrySet()) {
                                    String topic = obj.getKey();
                                    List<Object> values = obj.getValue();
                                    if(values!=null&&!values.isEmpty()) {
                                        String data = JSON.toJSONString(values);
                                        success = listener.handle(topic, data);
                                        if(SystemGlobalConfig.SYSTEM_DEBUG_VERBOSE) {
                                        	logger.info("---------------topic:{},key:{},value:{}", topic, null, data);
                                        }
                                        if(!success) {
                                            break;
                                        }
                                    }
                                }
                            }
                           
                            if (success && !autoCommit && ack != null) {
                                ack.acknowledge();
                            }
                            Thread.sleep(10);
                        } catch (Exception e) {
                            logger.error("--[Kafka-consumer(" + map.keySet() + ")]Data io error ! ", e);
                        }
                    }
                });
			}else {
			    container.setMessageListener(new AcknowledgingMessageListener<String, String>() {
                    @Override
                    public void onMessage(ConsumerRecord<String, String> obj, Acknowledgment ack) {
                        String topic = obj.topic();
                        String value = obj.value();
                        String key = obj.key();
                        try {
                        	if(SystemGlobalConfig.SYSTEM_DEBUG_VERBOSE) {
                        		logger.info("---------------topic:{},key:{},value:{}", topic, key, value);
                        	}
                            boolean flag = listener.handle(topic, value);
                            if (flag && !autoCommit && ack != null) {
                                ack.acknowledge();
                            }
                            Thread.sleep(10);
                        } catch (Exception e) {
                            logger.error("--[Kafka-consumer(" + topic + ")]Data io error ! ", e);
                        }
                    }
                });
			}
			service = new ConcurrentMessageListenerContainer<>(factory, container);
			service.setConcurrency(concurrency);
			service.start();
		} catch (Exception e) {
			logger.error("-----Kafka Config init Error-----", e);
		}
	}
	@Override
	public void start() {
		boolean delay = delay();
		if(!delay) {
			init();
		}
	    Executors.newSingleThreadExecutor().execute(() -> {
	        while (running) {
	            try {
	                if(listener==null) {
	                   logger.error("-----Kafka must have at least one consumer!");
	                   break; 
	                }
	                if(service==null||!service.isRunning()) {
	                	reconnect(); 
	                }
	                Thread.sleep(1000l);
	            } catch (InterruptedException e) {
	                logger.error("--Kafka Interrupted...",e);
	                Thread.currentThread().interrupt();
	            }
	        }
	    });
	}
	@Override
	public void reconnect() {
		close();
		init();
	}
	@Override
	public boolean delay() {
		 return true;
	}
	/**
	 * 关闭服务
	 */
	@Override
	public void close() {
		if (service != null) {
		    service.stop();
		}
	}
	
	/**
	 * @project HSF_Common
	 * @description Kafka消费策略
	 * @author ZhangYi
	 * @date 2019/10/17 14:18:14
	 * @version 1.0.0 
	 * @Jdk 1.8 
	 */
	public enum ComsumerStrategy {
	    RANGE,
	    ROUNDROBIN,
	    STICKY;
	    public static Class<?> strategy(String mode) {
	        if (StringUtils.isBlank(mode)) {
	            return RangeAssignor.class;
	        }
	        if(mode.equalsIgnoreCase(RANGE.name())) {
	            return RangeAssignor.class;
	        }
	        if(mode.equalsIgnoreCase(ROUNDROBIN.name())) {
	            return RoundRobinAssignor.class;
	        }
	        if(mode.equalsIgnoreCase(STICKY.name())) {
	            return StickyAssignor.class;
	        }
	        return RangeAssignor.class;
	    }
	}
}
