package com.hollysys.smartfactory.common.redis.factory.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.ReactiveRedisTemplate;

import com.hollysys.smartfactory.common.redis.IRedisProducerMessageListener;

/**
 * @decription Redis工厂(数据操作)
 * @author yi.zhang
 * @time 2019/09/18 08:44:52
 * @since 1.0
 * @jdk 1.8
 */
public class RedisProducerFactory extends RedisMessageFactory {
    private static final Logger logger = LoggerFactory.getLogger(RedisProducerFactory.class);
	private IRedisProducerMessageListener listener = null;
    public void setListener(IRedisProducerMessageListener listener) {
        this.listener = listener;
    }
    /**
	 * @decription 初始化配置
	 * @author yi.zhang
	 * @time 2017年6月2日 下午2:15:57
	 */
	public void init() {
		try {
		    super.build();
            ReactiveRedisTemplate<String,String> template = new ReactiveRedisTemplate<>(factory, super.serializer());
            String defaultTopic = REDIS_DEFAULT_TOPIC;
            if(topics!=null&&topics.length>0) {
                defaultTopic = topics[0];
            }
            listener.setDefaultTopic(defaultTopic);
            listener.setTemplate(template);
		} catch (Exception e) {
			logger.error("-----Redis Config init Error-----", e);
		}
	}
	@Override
	public boolean delay() {
		 return false;
	}
}
