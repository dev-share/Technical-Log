# 公共组件
为了解决公共组件工具包等，针对各层可以继承基类方便应用开发，减少开发量
## 一. 接口响应体
	AjaxResult以及ReturnInfo是对响应格式进行定义,为了统一响应格式
## 二. 工具类
-	DateUtils：日期工具类(对Date/LocalDateTime/LocalDate等日期的格式化、格式转换、时区转换、日期计算、日期合并、时间计算等封装)
-	CipherUtils：加解密算法(包括RSA/ECC/HMAC/AES/MD5等)
- 	FTPUtils：FTP文件的下载功能
- 	HttpUtils：对HTTP或HTTPS的请求操作(Get/Post/PUT/DELETE/Head/OPTIONS/METHOD_TRACE等)进行封装,并可以进行ping操作验证连通性以及URL的编解码功能
-	StringUtils： 字符串操作(补位、随机字符、判空等)
- 	其他工具类：Excel工具、集合工具等
