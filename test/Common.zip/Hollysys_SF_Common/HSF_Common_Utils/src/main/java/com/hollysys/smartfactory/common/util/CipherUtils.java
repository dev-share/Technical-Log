package com.hollysys.smartfactory.common.util;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;
/**
 * @project SF_Common_Service
 * @description 加密算法
 * @author ZhangYi
 * @date 2019/09/25 10:39:30
 * @version 1.0.0 
 * @Jdk 1.8
 */
public class CipherUtils {
    // decrypt encrypt
    public static final String CIPHER_KEY = "hollysys";
	static {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}

	/**
	 * @description RSA生成公钥私钥
	 * 作者:ZhangYi
	 * 时间:2019/09/25 3:26:16
	 * 参数：(参数列表)
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String[] generatorRSAKey() throws Exception {
		// 1.初始化密钥
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator.initialize(512);// 密钥长度为64的整数倍>=512，最大是65536
		KeyPair keyPair = keyPairGenerator.generateKeyPair();
		RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
		RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
		String pubKey = Hex.encodeHexString(publicKey.getEncoded());
		String priKey = Hex.encodeHexString(privateKey.getEncoded());
		return new String[] { pubKey, priKey };
	}

	/**
	 * @description ECC生成公钥私钥
	 * 作者:ZhangYi
	 * 时间:2019/09/25 3:26:16
	 * 参数：(参数列表)
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String[] generatorECCKey() throws Exception {
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("EC", "BC");
		keyPairGenerator.initialize(256, new SecureRandom());// 密钥长度为64的整数倍>=512，最大是65536
		KeyPair keyPair = keyPairGenerator.generateKeyPair();
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();
		String pubKey = Hex.encodeHexString(publicKey.getEncoded());
		String priKey = Hex.encodeHexString(privateKey.getEncoded());
		return new String[] { pubKey, priKey };
	}

	/**
	 * @description HMAC生成秘钥
	 * 作者:ZhangYi
	 * 时间:2019/09/25 3:26:16
	 * 参数：(参数列表)
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String generatorHMACKey() throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance("HmacSHA1");
		SecretKey secretKey = keyGenerator.generateKey();
		String pubKey = Hex.encodeHexString(secretKey.getEncoded());
		return pubKey;
	}

	/**
	 * 描述:[非对称算法]RSA加密(私钥加密)
	 * 作者:ZhangYi
	 * 时间:2019/09/25 2:21:24
	 * 参数：(参数列表)
	 * 
	 * @param target
	 * @return
	 * @throws Exception
	 */
	public static String encryptRSA(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pk);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey key = keyFactory.generatePrivate(keySpec);
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] hash = cipher.doFinal(target.getBytes());
		return Hex.encodeHexString(hash);
	}

	/**
	 * 描述:[非对称算法]RSA加密(私钥解密)
	 * 作者:ZhangYi
	 * 时间:2019/09/25 2:21:24
	 * 参数：(参数列表)
	 * 
	 * @param target
	 * @return
	 * @throws Exception
	 */
	public static String decryptRSA(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		Cipher cipher = Cipher.getInstance("RSA");
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(pk);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PublicKey key = keyFactory.generatePublic(keySpec);
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] data = Hex.decodeHex(target.toCharArray());
		byte[] hash = cipher.doFinal(data);
		return new String(hash);
	}

	/**
	 * 描述:[非对称算法]RSA加密(公钥加密)
	 * 作者:ZhangYi
	 * 时间:2019/09/25 2:21:24
	 * 参数：(参数列表)
	 * 
	 * @param target
	 * @return
	 * @throws Exception
	 */
	public static String encryptRSA2(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		Cipher cipher = Cipher.getInstance("RSA");
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(pk);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PublicKey key = keyFactory.generatePublic(keySpec);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] hash = cipher.doFinal(target.getBytes());
		return Hex.encodeHexString(hash);
	}

	/**
	 * 描述:[非对称算法]RSA加密(私钥解密)
	 * 作者:ZhangYi
	 * 时间:2019/09/25 2:21:24
	 * 参数：(参数列表)
	 * 
	 * @param target
	 * @return
	 * @throws Exception
	 */
	public static String decryptRSA2(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pk);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey key = keyFactory.generatePrivate(keySpec);
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] data = Hex.decodeHex(target.toCharArray());
		byte[] hash = cipher.doFinal(data);
		return new String(hash);
	}

	/**
	 * 描述:[非对称算法]ECC加密算法
	 * 作者:ZhangYi
	 * 时间:2019/09/25 3:33:30
	 * 参数：(参数列表)
	 * 
	 * @param target 加密数据
	 * @return
	 * @throws Exception
	 */
	public static String encryptECC(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(pk);
		KeyFactory keyFactory = KeyFactory.getInstance("EC", "BC");
		PublicKey key = keyFactory.generatePublic(keySpec);
		Cipher cipher = Cipher.getInstance("ECIES", "BC");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] hash = cipher.doFinal(target.getBytes());
		return Hex.encodeHexString(hash);
	}

	/**
	 * 描述:[非对称算法]ECC解密算法
	 * 作者:ZhangYi
	 * 时间:2019/09/25 2:21:24
	 * 参数：(参数列表)
	 * 
	 * @param target 解密数据
	 * @return
	 */
	public static String decryptECC(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pk);
		KeyFactory keyFactory = KeyFactory.getInstance("EC", "BC");
		PrivateKey key = keyFactory.generatePrivate(keySpec);
		Cipher cipher = Cipher.getInstance("ECIES", "BC");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] hash = cipher.doFinal(target.getBytes());
		return Hex.encodeHexString(hash);
	}

	/**
	 * 描述:[对称算法]AES加密算法
	 * 作者:ZhangYi
	 * 时间:2019/09/25 3:33:30
	 * 参数：(参数列表)
	 * 
	 * @param target 加密数据
	 * @return
	 * @throws Exception
	 */
	public static String encryptAES(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
		secureRandom.setSeed(pk);
		keyGenerator.init(128, secureRandom);
		SecretKey secretKey = keyGenerator.generateKey();
		byte[] enCodeFormat = secretKey.getEncoded();
		SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
		Cipher cipher = Cipher.getInstance("AES"); // 创建密码器
		byte[] byteContent = target.getBytes("utf-8");
		cipher.init(Cipher.ENCRYPT_MODE, key); // 初始化
		byte[] data = cipher.doFinal(byteContent);
		String encryptResultStr = Hex.encodeHexString(data);
		return encryptResultStr; // 加密
	}

	/**
	 * 描述:[对称算法]AES解密算法
	 * 作者:ZhangYi
	 * 时间:2019/09/25 2:21:24
	 * 参数：(参数列表)
	 * 
	 * @param target 解密数据
	 * @return
	 */
	public static String decryptAES(String target) throws Exception {
		byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
		secureRandom.setSeed(pk);
		keyGenerator.init(128, secureRandom);
		SecretKey secretKey = keyGenerator.generateKey();
		byte[] enCodeFormat = secretKey.getEncoded();
		SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
		Cipher cipher = Cipher.getInstance("AES"); // 创建密码器
		cipher.init(Cipher.DECRYPT_MODE, key); // 初始化
		byte[] data = cipher.doFinal(Hex.decodeHex(target.toCharArray()));
		return new String(data, "utf-8"); // 加密
	}

	/**
	 * 描述:[散列算法]MD5加密算法
	 * 作者:ZhangYi
	 * 时间:2019/09/25 9:04:40
	 * 参数：(参数列表)
	 * 
	 * @param target 目标内容
	 * @return
	 */
	public static String md5(String target) {
		try {
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			md5.reset();
			md5.update(target.getBytes());
			byte[] hash = md5.digest();
			return Hex.encodeHexString(hash);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 描述:[散列算法]HMAC加密算法
	 * 作者:ZhangYi
	 * 时间:2019/09/25 9:04:40
	 * 参数：(参数列表)
	 * 
	 * @param target 目标内容
	 * @return
	 */
	public static String hmac(String target) {
		try {
			byte[] pk = Hex.decodeHex(CIPHER_KEY.toCharArray());
			// 根据给定的字节数组构造一个密钥,第二参数指定一个密钥算法的名称
			SecretKey secretKey = new SecretKeySpec(pk, "HmacSHA1");
			// 生成一个指定 Mac 算法 的 Mac 对象
			Mac mac = Mac.getInstance("HmacSHA1");
			// 用给定密钥初始化 Mac 对象
			mac.init(secretKey);
			byte[] hash = mac.doFinal(target.getBytes());
			return Hex.encodeHexString(hash);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static void main(String[] args) {
        String key = "abc123";
        System.out.println(md5(key));
    }
}
