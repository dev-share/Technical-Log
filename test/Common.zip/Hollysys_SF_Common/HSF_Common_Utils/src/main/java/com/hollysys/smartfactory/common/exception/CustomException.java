package com.hollysys.smartfactory.common.exception;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Lists;

/**
 * @project SF_Common_Service
 * @description 自定义异常处理
 * @author ZhangYi
 * @date 2019/09/23 17:06:22
 * @version 1.0.0 
 * @Jdk 1.8
 */
public class CustomException extends RuntimeException {
    private static final long serialVersionUID = 12L;
    private int error;
    private List<String> errors = Lists.newArrayList();
    private int status = 200;

    public CustomException(int error, Throwable cause) {
        this(cause);
        this.error = error;
    }

    public CustomException(int error, String message) {
        this(message);
        this.error = error;
    }

    public CustomException(int error, String message, Throwable cause) {
        this(message, cause);
        this.error = error;
    }

    public CustomException(String message) {
        super(message);
    }

    public CustomException(Throwable cause) {
        super(cause);
    }

    public CustomException(String message, Throwable cause) {
        super(message, cause);
    }

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public List<String> getErrors() {
        return errors;
    }
    public String printErrors() {
        String msg = "";
        if(!errors.isEmpty()) {
            msg = StringUtils.join(errors, "\n");
        }
        return msg;
    }

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
