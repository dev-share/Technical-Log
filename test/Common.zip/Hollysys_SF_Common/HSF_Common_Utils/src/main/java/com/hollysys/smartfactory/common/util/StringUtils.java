package com.hollysys.smartfactory.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.net.util.Base64;
/**
 * @project SF_Common_Service
 * @description 字符串工具类
 * @author ZhangYi
 * @date 2019/09/24 18:40:56
 * @version 1.0.0 
 * @Jdk 1.8
 */
public class StringUtils extends org.apache.commons.lang3.StringUtils {
    /**
     * 分隔符:并号(&)
     */
    public static final String DELIMITER_AND = "&";
    /**
     * 分隔符:破折号(-)
     */
    public static final String DELIMITER_DASH = "-";
    /**
     * 分隔符:下划线(_)
     */
    public static final String DELIMITER_UNDERLINE = "_";
    /**
     * 分隔符:逗号(,)
     */
    public static final String DELIMITER_COMMA = ",";
    /**
     * 分隔符:点号(.)
     */
    public static final String DELIMITER_POINT = ".";
    /**
     * 分隔符:冒号(:)
     */
    public static final String DELIMITER_COLON = ":";
    /**
     * 分隔符:分号(;)
     */
    public static final String DELIMITER_SEMICOLON = ";";

    /**
     * 编码方式:UTF-8
     */
    public static final String ENCODING_UTF8 = StandardCharsets.UTF_8.name();
    /**
     * 编码方式:UTF-16
     */
    public static final String ENCODING_UTF16 = StandardCharsets.UTF_16.name();
    /**
     * 编码方式:GBK
     */
    public static final String ENCODING_GBK = "GBK";
    /**
     * 编码方式:GB2312
     */
    public static final String ENCODING_GB2312 = "GB2312";
    /**
     * 编码方式:ISO8859-1
     */
    public static final String ENCODING_ISO8859_1 = StandardCharsets.ISO_8859_1.name();
    /**
     * (数字+字母)字符库
     */
    public static final String[] CHARACTER_LIBRARY = new String[] {"0", "1", "2", "3", "4", "5", "6", "7",
        "8", "9", "a", "A", "b", "B", "c", "C", "d", "D", "e", "E", "f", "F", "g", "G", "h", "H",
        "i", "I", "j", "J", "k", "K", "l", "L", "m", "M", "n", "N", "o", "O", "p", "P", "q", "Q",
        "r", "R", "s", "S", "t", "T", "u", "U", "v", "V", "w", "W", "x", "X", "y", "Y", "z", "Z"};
    /**
     * @description 替换res中多个replacement为1个,并替换头尾replacement
     * @author ZhangYi
     * @date 2019/09/24 18:51:30
     * @param target 字符串源
     * @param replacement 替换标示 
     * @return
     */
    public static String replaceAll(String target, String replacement) {
      if (target.indexOf(replacement + replacement) == -1) {
        if (target.startsWith(replacement)) {
          target = target.substring(1);
        }
        if (target.endsWith(replacement)) {
          target = target.substring(0, target.length() - 1);
        }
        return target;
      } else {
        target = target.replaceAll(replacement + replacement, replacement);
      }
      return replaceAll(target, replacement);
    }
    /**
     * @description n位16进制随机数字
     * @author ZhangYi
     * @date 2019/09/24 18:55:17
     * @param n 长度
     * @return
     */
    public static String randomHexNumber(int n) {
      int j = 0;
      String number = "";
      while (j < (n - 1) / 4 + 1) {
        int i = new Random().nextInt(65536);
        String m = Integer.toHexString(i).toUpperCase();
        while (m.length() < 4) {
          m = "0" + m;
        }
        number += m;
        j++;
      }
      return number.substring(number.length() - n);
    }

    /**
     * @description n位随机数字
     * @author ZhangYi
     * @date 2019/09/24 18:54:10
     * @param len 随机数长度
     * @param flag 首位是否允许为0(true:首位大于0,false:首位任意数)
     * @return
     */
    public static String randomNumber(int len, boolean flag) {
      String number = new Random().nextInt(10) + "";
      if (flag) {
        while (number.equals("0")) {
          number = new Random().nextInt(10) + "";
        }
      }
      while (number.length() < len) {
        number += new Random().nextInt(10);
      }
      return number;
    }

    /**
     * @description 字符串填充0为固定长度,超出则截取
     * @author ZhangYi
     * @date 2019/09/24 18:53:27
     * @param source 源字符串
     * @param len 字符串长度
     * @param flag 填充位置(true:左填充/右截取,false:右填充/左截取)
     * @return
     */
    public static String fillString(String source, int len, boolean flag) {
      if (source.length() < len) {
        while (source.length() < len) {
          if (flag) {
            source = "0" + source;
          } else {
            source += "0";
          }
        }
      } else {
        if (flag) {
          source = source.substring(source.length() - len);
        } else {
          source = source.substring(0, len);
        }
      }
      return source;
    }
    /**
       *  描述:  base64编码
     * @author ZhangYi
     * @date 2019-10-24 11:47:38
     * @param target 目标字符串
     * @return
     */
    public static String encodeBase64(String target) {
    	return Base64.encodeBase64String(target.getBytes());
    }
    /**
     *  描述:  base64解码
   * @author ZhangYi
   * @date 2019-10-24 11:47:38
   * @param target 目标字符串
   * @return
   */
    public static String decodeBase64(String target) throws UnsupportedEncodingException {
    	return new String(Base64.decodeBase64(target), ENCODING_UTF8);
    }
    /**
     * @description 容量计算
     * @author ZhangYi
     * @date 2019/09/24 18:44:47
     * @param size 容量大小
     * @param isBit 容量是否bit
     * @return
     */
	public static String capacity(double size, boolean isBit) {
		String capacity = "";
		double diff = isBit ? size / 8 : size;
		double kb = diff / 1024;
		if (kb < 1024) {
			if (kb < 1) {
				capacity = String.format("%.2f", diff) + "B";
			} else {
				capacity = String.format("%.2f", kb) + "KB";
			}
			return capacity;
		}
		double mb = diff / (1024 * 1024);
		if (mb < 1024) {
			capacity = String.format("%.2f", mb) + "MB";
			return capacity;
		}
		double gb = diff / (1024 * 1024 * 1024);
		if (gb < 1024) {
			capacity = String.format("%.2f", gb) + "GB";
			return capacity;
		} else {
			double tb = diff / (1024 * 1024 * 1024 * 1024);
			capacity = String.format("%.2f", tb) + "TB";
		}
		return capacity;
	}
    /**
     * @description 时间差展示
     * @author ZhangYi
     * @date 2019/09/24 18:46:21
     * @param start 开始时间戳
     * @param end 结束时间戳
     * @return
     */
	public static String time(long start, long end) {
        String result = "";
        if(start<0||end<0) {
            return result; 
        }
        boolean flag = (end>=start);
        long diff = Math.abs(end-start);
        long millis = diff%1000;
        result = millis<1?"":(millis + "ms");
        diff = diff/1000;
        if(diff==0) {
            return result;
        }
        long second = diff%60;
        result = (second<1?"":second + "s")+result;
        diff = diff/60;
        if(diff==0) {
            return result;
        }
        long minute = diff%60;
        result = (minute<1?"":minute + "m")+result;
        diff = diff/60;
        if(diff==0) {
            return result;
        }
        long hour = diff%24;
        result = (hour<1?"":hour + "h")+result;
        diff = diff/24;
        if(diff==0) {
            return result;
        }
        result = (diff<1?"":diff + "d")+result;
        return (flag?"":"-")+result;
    }

	/**
	 * @description GZip压缩
	 * 作者: ZhangYi
	 * 时间: 2019年1月12日 上午9:17:15
	 * 参数: (参数列表)
	 * 
	 * @param target 压缩文本
	 * @return
	 */
	public static byte[] gzip(String target) {
		byte[] data = null;
		if (isEmpty(target)) {
			return data;
		}
		ByteArrayOutputStream out = null;
		GZIPOutputStream gout = null;
		try {
			out = new ByteArrayOutputStream();
			gout = new GZIPOutputStream(out);
			gout.write(target.getBytes());
			gout.finish();
			data = out.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();// 异常信息
		} finally {
			try {
				if (gout != null)
					gout.close();
				if (out != null)
					out.close();
			} catch (IOException e) {
				e.printStackTrace();// 异常信息
			}
		}
		return data;
	}

	/**
	 * @description GZip压缩文本解压
	 * 作者: ZhangYi
	 * 时间: 2019年1月12日 上午9:17:15
	 * 参数: (参数列表)
	 * 
	 * @param data 压缩数据
	 * @return
	 */
	public static String unGzip(byte[] data) {
		String target = null;
		if (data == null || data.length <= 0) {
			return target;
		}
		ByteArrayInputStream in = null;
		GZIPInputStream gin = null;
		ByteArrayOutputStream out = null;
		try {
			in = new ByteArrayInputStream(data);
			gin = new GZIPInputStream(in);
			out = new ByteArrayOutputStream();
			byte[] buf = new byte[512];
			int num = -1;
			while ((num = gin.read(buf, 0, buf.length)) != -1) {
				out.write(buf, 0, num);
			}
			target = new String(out.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();// 异常信息
		} finally {
			try {
				if (out != null)
					out.close();
				if (gin != null)
					gin.close();
				if (in != null)
					in.close();
			} catch (IOException e) {
				e.printStackTrace();// 异常信息
			}
		}
		return target;
	}

	public static void main(String[] args) {
//		System.out.println(capacity(24144, false));
		System.out.println(StandardCharsets.UTF_8.displayName());
		System.out.println(StandardCharsets.UTF_8.name());
	}
}
