package com.hollysys.smartfactory.common.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
/**
 * <pre>
 * 项目:公共类
 * 描述:Excel上传下载工具
 * 说明:POI技术实现
 * 作者:ZhangYi
 * 时间:2016年11月14日 下午4:11:29
 * 版本:wsm_v3.5
 * JDK:1.7.80
 * </pre>
 */
@SuppressWarnings("all")
public class ExcelUtils {
	private static Logger logger = LoggerFactory.getLogger(ExcelUtils.class);
	/**
	 * Excel版本：2003版
	 */
	public static final int EXCEL_VERSION_2003 = 2003;
	/**
	 * Excel版本：2007版
	 */
	public static final int EXCEL_VERSION_2007 = 2007;
	/**
	 * Excel版本：2010版
	 */
	public static final int EXCEL_VERSION_2010 = 2010;
	/**
	 * Excel版本：2013版
	 */
	public static final int EXCEL_VERSION_2013 = 2013;
	/**
	 * Excel版本：2016版
	 */
	public static final int EXCEL_VERSION_2016 = 2016;
	/**
	 * Excel版本：2016以上版
	 */
	public static final int EXCEL_VERSION_2016_PLUS = 2016;
	/**
	 * <pre>
	 * 描述:Excel导出
	 * 说明:(POI实现)
	 * 作者:ZhangYi
	 * 时间:2016年9月6日 下午3:07:55
	 * 参数：(参数列表)
	 * @param title		标题
	 * @param header	列标题
	 * @param rows		行数据
	 * @param response	响应请求
	 * @return
	 * </pre>
	 */
	public static boolean downloadExcel(String title, List<TreeMap<String,String>> rows,HttpServletResponse response) {
		return downloadExcel(title, rows, false,EXCEL_VERSION_2016_PLUS, response);
	}
	/**
	 * <pre>
	 * 描述:Excel导出
	 * 说明:(POI实现)
	 * 作者:ZhangYi
	 * 时间:2016年9月6日 下午3:07:55
	 * 参数：(参数列表)
	 * @param title		标题
	 * @param header	列标题
	 * @param rows		行数据
	 * @param isExtendFileName		是否扩展文件名(即文件名+日期[格式:yyyyMMddHHmmss])
	 * @param response	响应请求
	 * @return
	 * </pre>
	 */
	public static boolean downloadExcel(String title, List<TreeMap<String,String>> rows,boolean isExtendFileName,int version,HttpServletResponse response) {
		try {
			String extendName = isExtendFileName?DateUtils.formatDateTime(LocalDateTime.now(), "yyyyMMddHHmmss"):"";
			String fileName = new String(title.getBytes("GBK"), "ISO8859_1")+extendName+(version < EXCEL_VERSION_2007?".xls":"xlsm");
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setContentType("application/octet-stream"); // MediaType.APPLICATION_OCTET_STREAM_VALUE=application/octet-stream
			response.setHeader("Content-Disposition","attachment;filename=\"" + fileName + "\"");
			List<String> headers = new ArrayList<String>();
			if(rows!=null&&!rows.isEmpty()&&!rows.get(0).isEmpty()) {
				for(String key:rows.get(0).keySet()) {
					headers.add(key);
				}
			}
			if (version < EXCEL_VERSION_2007) {
				HSSFWorkbook book = new HSSFWorkbook();
				HSSFSheet sheet = book.createSheet(title);
				// sheet.autoSizeColumn(1, true);//自适应列宽度
				/******************************************************************************/
				// 1.通用样式字体设置
				HSSFFont font = book.createFont();// 字体设置
				font.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
				font.setFontHeightInPoints((short) 10);
				font.setBold(false);
				HSSFCellStyle style = book.createCellStyle();// 样式设置
				style.setAlignment(HorizontalAlignment.CENTER);// 水平对齐:居中
				style.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直对齐:居中
				style.setBorderBottom(BorderStyle.THIN); // 下边框
				style.setBorderLeft(BorderStyle.THIN);// 左边框
				style.setBorderTop(BorderStyle.THIN);// 上边框
				style.setBorderRight(BorderStyle.THIN);// 右边框
				style.setFont(font);
				// 2.(1)主题样式字体设置
				HSSFFont tfont = book.createFont();// 字体设置
				tfont.setColor(HSSFColor.HSSFColorPredefined.WHITE.getIndex());
				tfont.setFontHeightInPoints((short) 12);
				tfont.setBold(true);// 字体加粗
				HSSFCellStyle tstyle = book.createCellStyle();// 样式设置
				tstyle.setAlignment(HorizontalAlignment.CENTER);// 水平对齐:居中
				tstyle.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直对齐:居中
				tstyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.DARK_BLUE.getIndex());// 背景色:黑蓝色
				tstyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);// 填充色:纯色
				tstyle.setFont(tfont);
				// 2.(2)列标题样式字体设置
				HSSFCellStyle hstyle = book.createCellStyle();// 样式设置
				hstyle.setAlignment(HorizontalAlignment.CENTER);// 水平对齐:居中
				hstyle.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直对齐:居中
				hstyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREEN.getIndex());// 背景色:绿色
				hstyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);// 填充色:纯色
				hstyle.setBorderBottom(BorderStyle.THIN); // 下边框
				hstyle.setBorderLeft(BorderStyle.THIN);// 左边框
				hstyle.setBorderTop(BorderStyle.THIN);// 上边框
				hstyle.setBorderRight(BorderStyle.THIN);// 右边框
				hstyle.setFont(tfont);
				// 合并单元格供标题使用(表名)
				sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, headers.size() - 1));
				HSSFRow trow = sheet.createRow(0);// 第几行（从0开始）
				HSSFCell tcell = trow.createCell(0);
				trow.setHeightInPoints(51);
				tcell.setCellValue(title);
				tcell.setCellStyle(tstyle);
				HSSFRow row = sheet.createRow(1);
				row.setHeightInPoints(30);
				for (int i = 0; i < headers.size(); i++) {
					sheet.setColumnWidth(i, (headers.size() > 10 ? (headers.size() > 20 ? 10 : 17) : 22) * 256);// 列基数:256
					HSSFCell cell = row.createCell(i);
					String value = headers.get(i);
					cell.setCellValue(value);
					cell.setCellStyle(hstyle);
				}
				if (rows != null && rows.size() > 0) {
					for (int i = 0; i < rows.size(); i++) {
						row = sheet.createRow(i + 2);// index：第几行
						row.setHeightInPoints(18);
						TreeMap<String, String> map = rows.get(i);
						for (int j = 0; j < headers.size(); j++) {
							HSSFCell cell = row.createCell(j);// 第几列：从0开始
							String key = headers.get(j);
							String value = map.get(key);
							cell.setCellValue(value);
							cell.setCellStyle(style);
						}
					}
				}
				book.write(out);
			}else {
				XSSFWorkbook book = new XSSFWorkbook();
				XSSFSheet sheet = book.createSheet(title);
				// sheet.autoSizeColumn(1, true);//自适应列宽度
				/******************************************************************************/
				// 1.通用样式字体设置
				XSSFFont font = book.createFont();// 字体设置
				font.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
				font.setFontHeightInPoints((short) 10);
				font.setBold(false);
				XSSFCellStyle style = book.createCellStyle();// 样式设置
				style.setAlignment(HorizontalAlignment.CENTER);// 水平对齐:居中
				style.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直对齐:居中
				style.setBorderBottom(BorderStyle.THIN); // 下边框
				style.setBorderLeft(BorderStyle.THIN);// 左边框
				style.setBorderTop(BorderStyle.THIN);// 上边框
				style.setBorderRight(BorderStyle.THIN);// 右边框
				style.setFont(font);
				// 2.(1)主题样式字体设置
				XSSFFont tfont = book.createFont();// 字体设置
				tfont.setColor(HSSFColor.HSSFColorPredefined.WHITE.getIndex());
				tfont.setFontHeightInPoints((short) 12);
				tfont.setBold(true);// 字体加粗
				XSSFCellStyle tstyle = book.createCellStyle();// 样式设置
				tstyle.setAlignment(HorizontalAlignment.CENTER);// 水平对齐:居中
				tstyle.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直对齐:居中
				tstyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.DARK_BLUE.getIndex());// 背景色:黑蓝色
				tstyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);// 填充色:纯色
				tstyle.setFont(tfont);
				// 2.(2)列标题样式字体设置
				XSSFCellStyle hstyle = book.createCellStyle();// 样式设置
				hstyle.setAlignment(HorizontalAlignment.CENTER);// 水平对齐:居中
				hstyle.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直对齐:居中
				hstyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREEN.getIndex());// 背景色:绿色
				hstyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);// 填充色:纯色
				hstyle.setBorderBottom(BorderStyle.THIN); // 下边框
				hstyle.setBorderLeft(BorderStyle.THIN);// 左边框
				hstyle.setBorderTop(BorderStyle.THIN);// 上边框
				hstyle.setBorderRight(BorderStyle.THIN);// 右边框
				hstyle.setFont(tfont);
				/******************************************************************************/
				// 合并单元格供标题使用(表名)
				sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, headers.size() - 1));
				XSSFRow trow = sheet.createRow(0);// 第几行（从0开始）
				XSSFCell tcell = trow.createCell(0);
				trow.setHeightInPoints(51);
				tcell.setCellValue(title);
				tcell.setCellStyle(tstyle);
				XSSFRow row = sheet.createRow(1);
				row.setHeightInPoints(30);
				for (int i = 0; i < headers.size(); i++) {
					sheet.setColumnWidth(i, (headers.size() > 10 ? (headers.size() > 20 ? 10 : 17) : 22) * 256);// 列基数:256
					XSSFCell cell = row.createCell(i);
					String value = headers.get(i);
					cell.setCellValue(value);
					cell.setCellStyle(hstyle);
				}
				if (rows != null && rows.size() > 0) for (int i = 0; i < rows.size(); i++) {
					row = sheet.createRow(i + 2);// index：第几行
					row.setHeightInPoints(18);
					TreeMap<String, String> map = rows.get(i);
					for (int j = 0; j < headers.size(); j++) {
						XSSFCell cell = row.createCell(j);// 第几列：从0开始
						String key = headers.get(j);
						String value = map.get(key);
						cell.setCellValue(value);
						cell.setCellStyle(style);
					}
				}
				book.write(out);
			}
			out.flush();
			out.close();
			return true;
		}catch (Exception e) {
			logger.error("--Excel download error !", e);
			return false;
		}
	}
	/**
	 * <pre>
	 * 描述:读取多工作表的Excel工作薄(Excel版本:2007/2010+)
	 * 说明:(POI实现)Map(key为列名,value为行列值)为行对象
	 * 作者:ZhangYi
	 * 时间:2016年9月7日 下午6:47:30
	 * 参数：(参数列表)
	 * @param in		文件流
	 * @return	返回多行集合
	 * </pre>
	 */
	public static List<Map<String, Object>> readExcel(InputStream in) {
		return readExcel(in, EXCEL_VERSION_2016_PLUS,Collections.EMPTY_MAP,1, null);
	}
	/**
	   *  描述: 读取多工作表的Excel工作薄
	 * @author ZhangYi
	 * @date 2019-12-04 14:26:55
	 * @param in	文件流
	 * @param header 表头替换(key:Excel原始表头,value:替换表头字段)
	 * @return
	 */
	public static List<Map<String, Object>> readExcel(InputStream in,Map<String, String> header) {
		return readExcel(in, EXCEL_VERSION_2016_PLUS,header,1, null);
	}
	/**
	   *  描述: 读取多工作表的Excel工作薄
	 * @author ZhangYi
	 * @date 2019-12-04 14:26:55
	 * @param in	文件流
	 * @param header 表头替换(key:Excel原始表头,value:替换表头字段)
	 * @param clazz JavaBean对象(header中的value对应其字段)
	 * @return
	 */
	public static <T> List<T> readExcel(InputStream in,Map<String, String> header,Class<T> clazz) {
		List<Map<String, Object>> list = readExcel(in, EXCEL_VERSION_2016_PLUS,header,1, null);
		List<T> objs = JSON.parseArray(JSON.toJSONString(list), clazz);
		return objs;
	}
	/**
	 * <pre>
	 * 描述:读取多工作表的Excel工作薄
	 * 说明:(POI实现)Map(key为列名,value为行列值)为行对象
	 * 作者:ZhangYi
	 * 时间:2016年9月7日 下午6:47:30
	 * 参数：(参数列表)
	 * @param in		文件流
	 * @param version	Excel版本(2003/2007/2010+)
	 * @param header	表头替换(key:Excel原始表头,value:替换表头字段)
	 * @param srow		起始行(包含表头[默认:1])
	 * @param sheet	工作表名称(空值为所有工作表)
	 * @return	返回多行集合
	 * </pre>
	 */
	public static List<Map<String, Object>> readExcel(InputStream in, int version,Map<String, String> header,int srow, String sheet) {
		if (in == null) return null;
		List<Map<String, Object>> list = null;
		try {
			srow = srow<1?1:srow;
			if (version < EXCEL_VERSION_2007) {
				HSSFWorkbook workbook = new HSSFWorkbook(new POIFSFileSystem(in));
				int count = workbook.getNumberOfSheets();// 工作表数目
				if (count > 0) {
					list = new ArrayList<Map<String, Object>>();
					for (int k = 0; k < count; k++) {
						HSSFSheet hsheet = workbook.getSheetAt(k);// 当前工作表
						if (!StringUtils.isEmpty(sheet) && !sheet.equalsIgnoreCase(hsheet.getSheetName())) {
							continue;
						}
						int rowNum = hsheet.getLastRowNum();// 得到总行数
						if (rowNum == 0) {
							continue;
						}
						int colNum = hsheet.getRow(srow-1).getPhysicalNumberOfCells();
						for (int i = srow; i <= rowNum; i++) {// 正文内容应该从第二行开始,第一行为表头的标题
							boolean rowvalue = false;//判断行是否全为空,默认空行
							HSSFRow row = hsheet.getRow(i);// 行
							Map<String, Object> obj = new HashMap<String, Object>();// 相当对象
							for (int j = 0; j < colNum; j++) {
								HSSFCell cell = hsheet.getRow(0).getCell(j);
								if(cell == null||cell.getCellType() != CellType.STRING)continue;
								String key = cell.getStringCellValue();// 标题
								cell = row.getCell(j);
								Object value = "";// 列值
								if(cell!=null){
									if (cell.getCellType() == CellType.STRING) {
										value = cell.getStringCellValue();
									}
									if (cell.getCellType() == CellType.NUMERIC) {
										value = cell.getNumericCellValue();
										if (HSSFDateUtil.isCellDateFormatted(cell)) {
											value = cell.getDateCellValue();
										}
									}
									if (cell.getCellType() == CellType.BOOLEAN) {
										value = cell.getBooleanCellValue();
									}
								}
								if(value!=null&&!StringUtils.isEmpty((String)value)){
									rowvalue = true;
								}
								obj.put(CollectionUtils.sizeIsEmpty(header)||!header.containsKey(key)?key:header.get(key), value);// 相当对象属性
							}
//							if(rowvalue){
//							}
								list.add(obj);
						}
					}
				}
			} else {
				XSSFWorkbook workbook = new XSSFWorkbook(in);
				int count = workbook.getNumberOfSheets();// 工作表数目
				if (count > 0) {
					list = new ArrayList<Map<String, Object>>();
					for (int k = 0; k < count; k++) {
						XSSFSheet hsheet = workbook.getSheetAt(k);// 当前工作表
						if (!StringUtils.isEmpty(sheet) && !sheet.equalsIgnoreCase(hsheet.getSheetName())) {
							continue;
						}
						int rowNum = hsheet.getLastRowNum();// 得到总行数
						if (rowNum == 0) {
							continue;
						}
						int colNum = hsheet.getRow(srow-1).getPhysicalNumberOfCells();
						for (int i = srow; i <= rowNum; i++) {// 正文内容应该从第二行开始,第一行为表头的标题
							boolean rowvalue = false;//判断行是否全为空,默认空行
							XSSFRow row = hsheet.getRow(i);// 行
							Map<String, Object> obj = new HashMap<String, Object>();// 相当对象
							for (int j = 0; j < colNum; j++) {
								XSSFCell cell = hsheet.getRow(0).getCell(j);
								if(cell == null||cell.getCellType() != CellType.STRING)continue;
								String key = cell.getStringCellValue();// 标题
								cell = row.getCell(j);
								Object value = null;// 列值
								if(cell!=null){
									if (cell.getCellType() == CellType.STRING) {
										value = cell.getStringCellValue();
									}
									if (cell.getCellType() == CellType.NUMERIC) {
										value = cell.getNumericCellValue();
										if (cell.getDateCellValue() != null) {
											value = cell.getDateCellValue();
										}
									}
									if (cell.getCellType() == CellType.BOOLEAN) {
										value = cell.getBooleanCellValue();
									}
								}
								if(value!=null&&!StringUtils.isEmpty((String)value)){
									rowvalue = true;
								}
								obj.put(CollectionUtils.sizeIsEmpty(header)||!header.containsKey(key)?key:header.get(key), value);// 相当对象属性
							}
//							if(rowvalue){
//							}
							list.add(obj);
						}
					}
				}
			}
			in.close();
		} catch (Exception e) {
			logger.error("--Excel read error !", e);
		}
		return list;
	}
}
